"""Pure text-presentation helpers shared across agentgrep surfaces.

Privacy-safe path rendering, query-syntax highlighting (the single source of
truth consumed by the CLI help, the Textual TUI, and the docs lexer), help-text
assembly, match highlighting, truncation, and body-format sniffing. Depends only
on the standard library and Rich; it imports no engine, adapter, or frontend
module.
"""

from __future__ import annotations

import collections
import dataclasses
import json
import os
import pathlib
import re
import textwrap
import typing as t
import unicodedata

from rich.text import Text as _RichText

if t.TYPE_CHECKING:
    import collections.abc as cabc

    from agentgrep.records import ColorMode

    PrivatePathBase = pathlib.Path
else:
    PrivatePathBase = type(pathlib.Path())

__all__ = [
    "ANSI_CSI_RE",
    "CLI_DESCRIPTION",
    "DETAIL_BODY_MAX_CHARS",
    "DETAIL_BODY_MAX_LINES",
    "FIND_DESCRIPTION",
    "GREP_DESCRIPTION",
    "INLINE_CODE_RE",
    "MARKUP_HIGHLIGHT_ROLES",
    "MARKUP_TOKEN_RE",
    "QUERY_BOOLEAN_KEYWORDS",
    "QUERY_FIELD_TOKEN_RE",
    "QUERY_HIGHLIGHT_ROLES",
    "QUERY_TOKEN_RE",
    "SEARCH_DESCRIPTION",
    "SHELL_TOKEN_RE",
    "UI_DESCRIPTION",
    "AnsiColors",
    "ContentFormat",
    "PrivatePath",
    "build_description",
    "detect_content_format",
    "find_first_match_line",
    "format_compact_path",
    "format_display_path",
    "highlight_markup_spans",
    "highlight_matches",
    "highlight_query_spans",
    "should_enable_color",
    "truncate_lines",
]


ANSI_CSI_RE = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")
_ANSI_RESET = "\x1b[0m"  # ANSI SGR reset

# Query-language highlighting inside help example lines. Detected by shape — a
# standalone boolean keyword or a ``field:`` predicate — so the help formatter
# never imports the query module (cold-start) and never couples to the
# registry. Help examples are author-controlled, so a shape-only field test is
# enough (a stray ``https:`` would only ever appear if someone wrote it).
QUERY_BOOLEAN_KEYWORDS: frozenset[str] = frozenset({"AND", "OR", "NOT", "TO"})
# Detection: a (possibly negated) field predicate, quotes already stripped.
QUERY_FIELD_TOKEN_RE = re.compile(r"^[+-]?[A-Za-z_][A-Za-z0-9_.-]*:")
# Shell-aware split that keeps a whole quoted argument together so a quoted
# query (``'agent:codex migration'``) is highlighted as one expression.
SHELL_TOKEN_RE = re.compile(r"""\s+|'(?:\\.|[^'\\])*'|"(?:\\.|[^"\\])*"|\S+""")
# Query-expression lexer: one pass over the unquoted query body. Order matters
# (longest / most specific alternatives first).
QUERY_TOKEN_RE = re.compile(
    r"""
      (?P<SPACE>\s+)
    | (?P<PHRASE>"(?:\\.|[^"\\])*")
    | (?P<BOOL>\b(?:AND|OR|NOT|TO)\b)
    | (?P<FIELD>[A-Za-z_][\w.-]*)(?=\s*:)
    | (?P<DATE>\b\d{4}-\d{2}-\d{2}(?:[Tt]\d{2}:\d{2}(?::\d{2})?(?:Z|[+-]\d{2}:\d{2})?)?\b)
    | (?P<SIGN>(?<![\w])[-+])
    | (?P<OP>>=|<=|[!~^:><=])
    | (?P<PUNCT>[\[\]\(\)\{\}])
    | (?P<WILD>[*?])
    | (?P<WORD>[^\s\[\]\(\)\{\}:"~^><=!*?+]+)
    | (?P<MISC>.)
    """,
    re.VERBOSE,
)
# RST inline-code span (``code``) used in help intro prose.
INLINE_CODE_RE = re.compile(r"``([^`]+)``")

# Semantic roles emitted by :func:`highlight_query_spans`. The query-language
# grammar is lexed once here and shared by every highlighter — the CLI ANSI
# help (this module), the Textual TUI (``agentgrep.ui.highlighter``), and the
# Sphinx/MyST docs (``agentgrep.query.pygments_lexer``) — so the surfaces never
# drift. Each consumer maps these role strings to its own styling.
QUERY_HIGHLIGHT_ROLES: frozenset[str] = frozenset(
    {
        "whitespace",
        "field",
        "keyword",
        "negation",
        "operator",
        "punct",
        "wildcard",
        "date",
        "phrase",
        "value",
    },
)
# QUERY_TOKEN_RE group name -> semantic role. ``OP`` is special-cased (``:`` is
# punctuation, every other operator is a comparison/range operator).
_QUERY_TOKEN_GROUP_ROLES: dict[str, str] = {
    "SPACE": "whitespace",
    "PHRASE": "phrase",
    "BOOL": "keyword",
    "FIELD": "field",
    "DATE": "date",
    "SIGN": "negation",
    "PUNCT": "punct",
    "WILD": "wildcard",
    "WORD": "value",
    "MISC": "value",
}


def highlight_query_spans(query: str) -> list[tuple[int, str, str]]:
    """Lex a query string into contiguous ``(start, role, text)`` spans.

    The single source of truth for query-language syntax highlighting. The
    returned spans cover ``query`` end to end (including whitespace), in order,
    so a consumer can rebuild the string or stylize by offset. ``role`` is one
    of :data:`QUERY_HIGHLIGHT_ROLES`.

    Parameters
    ----------
    query : str
        The query expression (no surrounding shell quotes).

    Returns
    -------
    list[tuple[int, str, str]]
        ``(start_offset, role, text)`` spans in source order.

    Examples
    --------
    >>> highlight_query_spans("agent:codex")
    [(0, 'field', 'agent'), (5, 'punct', ':'), (6, 'value', 'codex')]
    >>> [role for _, role, _ in highlight_query_spans("ruff OR uv")]
    ['value', 'whitespace', 'keyword', 'whitespace', 'value']
    """
    spans: list[tuple[int, str, str]] = []
    for match in QUERY_TOKEN_RE.finditer(query):
        group = match.lastgroup or "MISC"
        text = match.group()
        if group == "OP":
            role = "punct" if text == ":" else "operator"
        else:
            role = _QUERY_TOKEN_GROUP_ROLES.get(group, "value")
        spans.append((match.start(), role, text))
    return spans


# XML/markup structural lexer: one pass over a body that
# :func:`looks_like_markup` has already classified as tag-shaped. Prompt bodies
# from agent stores are mostly prose with sparse structural tags
# (``<EPHEMERAL_MESSAGE>``, ``<bash_command_reminder>``, closers). This mirrors
# the query-language lexer (:func:`highlight_query_spans`) exactly: a shared
# grammar lexed once, each frontend mapping the role strings to its own styling.
# Order matters (longest / most specific alternatives first). Delimiters carry
# their own tokens; a tag ``NAME`` is anchored by a lookbehind on ``<`` / ``</``
# so a bare word in prose can never be mistaken for one. ``.`` under DOTALL is
# the terminal catch-all, so the spans cover the body end to end.
MARKUP_TOKEN_RE = re.compile(
    r"""
      (?P<COMMENT><!--.*?-->)
    | (?P<CLOSEDELIM></)
    | (?P<SELFCLOSE>/>)
    | (?P<OPENDELIM><(?=[A-Za-z/!]))
    | (?P<CLOSE>>)
    | (?P<NAME>(?<=<)[A-Za-z][\w:.-]*|(?<=</)[A-Za-z][\w:.-]*)
    | (?P<WS>\s+)
    | (?P<ATTRVALUE>"[^"]*"|'[^']*')
    | (?P<ATTRNAME>[A-Za-z_:][\w:.-]*(?=\s*=))
    | (?P<EQ>=)
    | (?P<TEXT>[^<>]+|.)
    """,
    re.VERBOSE | re.DOTALL,
)
# Semantic roles emitted by :func:`highlight_markup_spans`. Like the query
# roles, each consumer maps these strings to its own styling; ``text`` is the
# unstyled default a highlighter skips.
MARKUP_HIGHLIGHT_ROLES: frozenset[str] = frozenset(
    {
        "tag-delim",
        "tag-name",
        "attr-name",
        "attr-value",
        "comment",
        "text",
    },
)
# MARKUP_TOKEN_RE group name -> semantic role. Everything not a tag delimiter,
# name, attribute, or comment is prose ``text``.
_MARKUP_TOKEN_GROUP_ROLES: dict[str, str] = {
    "COMMENT": "comment",
    "CLOSEDELIM": "tag-delim",
    "SELFCLOSE": "tag-delim",
    "OPENDELIM": "tag-delim",
    "CLOSE": "tag-delim",
    "NAME": "tag-name",
    "WS": "text",
    "ATTRVALUE": "attr-value",
    "ATTRNAME": "attr-name",
    "EQ": "text",
    "TEXT": "text",
}


def highlight_markup_spans(text: str) -> list[tuple[int, str, str]]:
    """Lex a markup-shaped body into contiguous ``(start, role, text)`` spans.

    The single source of truth for structural-tag highlighting, mirroring
    :func:`highlight_query_spans`. The returned spans cover ``text`` end to end
    (including prose ``text`` runs), in source order, so a consumer can rebuild
    the string or stylize by offset. ``role`` is one of
    :data:`MARKUP_HIGHLIGHT_ROLES`.

    This is a shape-only lexer: it does not validate nesting. Callers gate on
    :func:`looks_like_markup` first so a stray ``<`` in prose or code
    (``List<int>``, ``a < b``) is never styled.

    The lexer is tag-context aware: ``attr-name`` / ``attr-value`` roles are
    emitted only between an open ``<`` delimiter and its closing ``>`` (or
    ``/>``). A prose ``key = value`` or a quoted phrase outside a tag stays
    ``text`` — the token grammar alone would otherwise mistake it for an
    attribute inside a body that has already passed the markup gate.

    Parameters
    ----------
    text : str
        The body to lex.

    Returns
    -------
    list[tuple[int, str, str]]
        ``(start_offset, role, text)`` spans in source order.

    Examples
    --------
    >>> highlight_markup_spans("<a>")
    [(0, 'tag-delim', '<'), (1, 'tag-name', 'a'), (2, 'tag-delim', '>')]
    >>> {role for _, role, _ in highlight_markup_spans("a < b")}
    {'text'}
    >>> {role for _, role, _ in highlight_markup_spans("key = value")}
    {'text'}
    >>> sorted({role for _, role, _ in highlight_markup_spans('<t k="v">')})
    ['attr-name', 'attr-value', 'tag-delim', 'tag-name', 'text']
    """
    spans: list[tuple[int, str, str]] = []
    in_tag = False
    for match in MARKUP_TOKEN_RE.finditer(text):
        group = match.lastgroup or "TEXT"
        role = _MARKUP_TOKEN_GROUP_ROLES.get(group, "text")
        if group in ("OPENDELIM", "CLOSEDELIM"):
            in_tag = True
        elif group in ("CLOSE", "SELFCLOSE"):
            in_tag = False
        elif role in ("attr-name", "attr-value") and not in_tag:
            # A tag-shaped token in prose (``key = value``, a quoted phrase)
            # outside any ``<...>`` is not an attribute.
            role = "text"
        spans.append((match.start(), role, match.group()))
    return spans


def build_description(
    intro: str,
    example_blocks: cabc.Sequence[tuple[str | None, cabc.Sequence[str]]],
) -> str:
    """Assemble help text with example sections."""
    sections: list[str] = []
    intro_text = textwrap.dedent(intro).strip()
    if intro_text:
        sections.append(intro_text)

    for heading, commands in example_blocks:
        if not commands:
            continue
        title = "examples:" if heading is None else f"{heading} examples:"
        lines = [title]
        lines.extend(f"  {command}" for command in commands)
        sections.append("\n".join(lines))

    return "\n\n".join(sections)


CLI_DESCRIPTION = build_description(
    """
    Read-only search across Codex, Claude, Cursor, Gemini, Antigravity,
    Grok, Pi, and OpenCode local stores. Pick a subcommand from the list below:
    ``search`` for ranked results with dedup and session grouping,
    ``grep`` for rg-shaped content search, ``find`` for store
    enumeration, ``ui`` for the interactive Textual explorer.
    """,
    (
        (
            "search",
            (
                "agentgrep search streaming parser",
                "agentgrep search --deep migration",
                "agentgrep search --exhaustive migration",
                "agentgrep search --here deploy",
                "agentgrep search 'ruff OR uv'",
                "agentgrep search 'agent:codex migration'",
                "agentgrep search '\"exact phrase\"'",
            ),
        ),
        (
            "grep",
            (
                "agentgrep grep bliss",
                "agentgrep grep --deep TODO",
                "agentgrep grep --exhaustive TODO",
                "agentgrep grep -i 'serene bliss'",
                "agentgrep grep -F --scope conversations TODO",
                "agentgrep grep 'cwd:~/work/django-project deploy'",
                "agentgrep grep --json design",
            ),
        ),
        (
            "find",
            (
                "agentgrep find codex",
                "agentgrep find -t prompts -e jsonl",
                "agentgrep find 'path:*workspaceStorage* agent:cursor-ide'",
                "agentgrep find cursor-cli --json",
            ),
        ),
        (
            "ui",
            (
                "agentgrep ui",
                "agentgrep ui bliss",
                "agentgrep search --deep migration --ui",
                "agentgrep search --exhaustive migration --ui",
            ),
        ),
    ),
)
FIND_DESCRIPTION = build_description(
    """
    Find known prompt, history, and store paths without parsing message text.
    """,
    (
        (
            None,
            (
                "agentgrep find codex",
                "agentgrep find sessions --agent codex",
                "agentgrep find 'path:*workspaceStorage* agent:cursor-ide'",
                "agentgrep find cursor-cli --json",
            ),
        ),
    ),
)
UI_DESCRIPTION = build_description(
    """
    Launch the interactive Textual explorer over fast prompt-history stores.
    After a search, use /deep for selected conversations or /exhaustive for
    every readable conversation. The same depth is available at launch through
    search --deep ... --ui and search --exhaustive ... --ui.
    """,
    (
        (
            None,
            (
                "agentgrep ui",
                "agentgrep ui bliss",
                "agentgrep search --deep migration --ui",
                "agentgrep search --exhaustive migration --ui",
            ),
        ),
    ),
)
SEARCH_DESCRIPTION = build_description(
    """
    Smart search with relevance ranking, deduplication, and session grouping.
    Uses rapidfuzz for scoring — results sorted by match quality.

    Fast by default: reads prompt-history stores only. ``--deep`` uses prompt
    matches to select a bounded set of conversations; ``--exhaustive`` scans
    every readable conversation backend. A ``depth:`` (alias ``effort:``)
    query term selects the same read policy inline.

    Terms accept a query language: bare terms are AND-combined substrings;
    compose with OR / NOT / ( ); quote "exact phrases"; filter by field
    (agent:, model:, role:, timestamp:, path:, scope:, depth:). field:* tests
    presence and field:glob* matches wildcards.
    """,
    (
        (
            None,
            (
                "agentgrep search streaming parser",
                "agentgrep search --deep migration",
                "agentgrep search --exhaustive migration",
                "agentgrep search --here deploy",
                "agentgrep search --cwd ~/work/django-project deploy",
                "agentgrep search --threshold 70 migration",
                "agentgrep search --no-rank --no-group caching",
                "agentgrep search bliss --json",
            ),
        ),
        (
            "query language",
            (
                "agentgrep search 'ruff OR uv'",
                "agentgrep search 'agent:codex migration'",
                "agentgrep search '\"exact phrase\"'",
                "agentgrep search 'timestamp:>2026-01-01 release'",
                "agentgrep search 'scope:all model:gpt* caching'",
                "agentgrep search 'depth:exhaustive migration'",
                "agentgrep search 'cwd:~/work/django-project deploy'",
                "agentgrep search 'project:docs branch:main deploy'",
                "agentgrep search 'deploy -agent:cursor-cli'",
            ),
        ),
    ),
)
GREP_DESCRIPTION = build_description(
    """
    Content search across normalized records with rg/ag-shaped flags.

    Defaults: smart-case, regex, session-deduped output. Pass
    ``--no-dedupe`` for the raw rg view, ``-F`` for literal pattern
    matching, ``-i`` / ``-s`` to override case, ``--json`` for an
    rg-style event stream.

    Fast by default: reads prompt-history stores only. ``--deep`` uses prompt
    matches to select a bounded set of conversations; ``--exhaustive`` scans
    every readable conversation backend. A ``depth:`` (alias ``effort:``)
    query term selects the same read policy inline.

    Patterns accept the same query language as ``search`` (field
    predicates, OR / NOT, "phrases"), but grep needs at least one text
    pattern to drive line-level matching.
    """,
    (
        (
            None,
            (
                "agentgrep grep bliss",
                "agentgrep grep --deep TODO",
                "agentgrep grep --exhaustive TODO",
                "agentgrep grep -i 'serene bliss'",
                "agentgrep grep -F --scope conversations TODO",
                "agentgrep grep --json design",
                "agentgrep grep --vimgrep --no-dedupe foo",
            ),
        ),
        (
            "query language",
            (
                "agentgrep grep 'agent:codex deploy'",
                "agentgrep grep 'role:user TODO'",
                "agentgrep grep 'cwd:~/work/django-project deploy'",
                "agentgrep grep 'fixme OR todo'",
            ),
        ),
    ),
)


class PrivatePath(PrivatePathBase):
    """Path subclass that hides the user's home directory in textual output."""

    def __new__(cls, *args: t.Any, **kwargs: t.Any) -> t.Self:
        """Create a privacy-aware path."""
        return super().__new__(cls, *args, **kwargs)

    @classmethod
    def _collapse_home(cls, value: str) -> str:
        """Collapse the user's home directory to ``~`` when ``value`` is inside it."""
        if value.startswith("~"):
            return value

        home = str(pathlib.Path.home())
        if value == home:
            return "~"

        separators = {os.sep}
        if os.altsep:
            separators.add(os.altsep)

        for separator in separators:
            home_with_separator = home + separator
            if value.startswith(home_with_separator):
                return "~" + value[len(home) :]

        return value

    def __str__(self) -> str:
        """Return string output with the home directory collapsed."""
        return self._collapse_home(pathlib.Path.__str__(self))

    def __repr__(self) -> str:
        """Return repr output with the home directory collapsed."""
        return f"{self.__class__.__name__}({str(self)!r})"


def format_display_path(path: pathlib.Path | str, *, directory: bool = False) -> str:
    """Return a privacy-safe display path."""
    display = str(PrivatePath(path))
    if directory and not display.endswith("/"):
        return f"{display.rstrip('/')}/"
    return display


def format_compact_path(path: pathlib.Path | str, *, max_width: int) -> str:
    """Trim a long display path with middle-elision, fish-style adapted for our shapes.

    Our paths are date-segmented (`~/.codex/sessions/2024/02/14/uuid.jsonl`) so
    fish-shell's first-letter abbreviation (`~/.c/s/2/0/1/uuid.jsonl`) loses
    information. Instead we preserve the leading hidden-dir context, the
    filename, and the immediate parent dir; the middle is elided with `…/`.

    Parameters
    ----------
    path : pathlib.Path | str
        Source path; passed through :func:`format_display_path` first so the
        privacy-rewriting and ``~`` prefix logic stay consistent with the CLI.
    max_width : int
        Maximum number of display columns.

    Returns
    -------
    str
        A path string of at most ``max_width`` columns (best-effort; if even
        the filename exceeds the budget the filename is hard-truncated with
        ``…``).
    """
    display = format_display_path(path)
    if max_width <= 0 or len(display) <= max_width:
        return display
    # Split preserving leading ``~`` / ``/`` so we can rebuild correctly.
    if display.startswith("~/"):
        prefix = "~/"
        body = display[2:]
    elif display.startswith("/"):
        prefix = "/"
        body = display[1:]
    else:
        prefix = ""
        body = display
    segments = body.split("/")
    if len(segments) <= 2:
        return _hard_truncate(display, max_width)
    root = segments[0]
    filename = segments[-1]
    parent = segments[-2]
    # Tier 1: keep root + …/ + parent + / + filename
    candidate = f"{prefix}{root}/…/{parent}/{filename}"
    if len(candidate) <= max_width:
        return candidate
    # Tier 2: drop root, keep …/ + parent + / + filename
    candidate = f"…/{parent}/{filename}"
    if len(candidate) <= max_width:
        return candidate
    # Tier 3: keep just the filename, possibly truncated.
    return _hard_truncate(filename, max_width)


def _hard_truncate(text: str, max_width: int) -> str:
    """Truncate ``text`` to fit ``max_width``, appending ``…`` if shortened."""
    if max_width <= 0:
        return ""
    if len(text) <= max_width:
        return text
    if max_width == 1:
        return "…"
    return text[: max_width - 1] + "…"


def _char_cells(char: str) -> int:
    r"""Return how many terminal cells ``char`` occupies when displayed.

    ``rich.cells.cell_len`` is already importable here and is more accurate for
    grapheme clusters, but it undercounts some combining scripts. Undercounting
    is the direction that wraps a status line and strands a row; this rule only
    ever over-reserves.

    Parameters
    ----------
    char : str
        A single character.

    Returns
    -------
    int
        ``0`` for a combining mark, which renders on top of the preceding
        character; ``2`` for East Asian Wide and Fullwidth characters; ``1``
        otherwise.

    Examples
    --------
    >>> _char_cells("a")
    1
    >>> _char_cells("会")
    2
    >>> _char_cells("́")
    0
    """
    if unicodedata.combining(char):
        return 0
    return 2 if unicodedata.east_asian_width(char) in {"W", "F"} else 1


def _visible_width(text: str) -> int:
    r"""Return display cells occupied after stripping ANSI CSI escape sequences.

    Parameters
    ----------
    text : str
        Text that may carry ANSI CSI escape sequences.

    Returns
    -------
    int
        Terminal cells the text occupies. Wide characters count two, so a
        caller sizing a single-line status against the terminal width does not
        overflow it and wrap.

    Examples
    --------
    >>> _visible_width("plain ascii")
    11
    >>> _visible_width("会话记录")
    8
    >>> _visible_width("\x1b[36m会話\x1b[0m")
    4
    """
    return sum(_char_cells(char) for char in ANSI_CSI_RE.sub("", text))


def _hard_truncate_ansi(text: str, max_width: int) -> str:
    """Truncate ANSI-colored text to at most ``max_width`` display cells.

    A character whose cell cost would exceed the remaining budget is rejected
    rather than appended: admitting it would emit a two-cell character into a
    one-cell remainder and return a string wider than ``max_width``.

    Parameters
    ----------
    text : str
        Text that may carry ANSI CSI escape sequences.
    max_width : int
        Cell budget for the result, ellipsis included. ``0`` or less yields an
        empty string.

    Returns
    -------
    str
        ``text`` unchanged when it already fits, otherwise a prefix ending in
        ``…``. Escape sequences are carried through for free and a trailing
        reset is appended when any were kept, so a truncation cannot leak color
        into whatever the caller writes next.

    Examples
    --------
    >>> _hard_truncate_ansi("abcdef", 4)
    'abc…'
    >>> _hard_truncate_ansi("会话记录", 5)
    '会话…'
    """
    if max_width <= 0:
        return ""
    if _visible_width(text) <= max_width:
        return text
    if max_width == 1:
        return "…"
    budget = max_width - 1
    output: list[str] = []
    visible = 0
    index = 0
    saw_escape = False
    while index < len(text):
        match = ANSI_CSI_RE.match(text, index)
        if match is not None:
            output.append(match.group(0))
            index = match.end()
            saw_escape = True
            continue
        cells = _char_cells(text[index])
        if visible + cells > budget:
            break
        output.append(text[index])
        visible += cells
        index += 1
    output.append("…")
    if saw_escape:
        output.append(_ANSI_RESET)
    return "".join(output)


def truncate_lines(
    text: str,
    max_lines: int,
    *,
    max_chars: int | None = None,
) -> str:
    """Return a bounded prefix of ``text``, with an overflow marker.

    Used by the TUI detail pane so a record body of any size renders in
    bounded time — only the configured character and line prefix is passed to
    the ``Static`` widget. Line-only overflow retains an exact count; character
    overflow uses a generic marker so the bound never scans the omitted tail.
    """
    if max_lines <= 0 or not text or (max_chars is not None and max_chars <= 0):
        return ""
    chars_truncated = max_chars is not None and len(text) > max_chars
    bounded = text[:max_chars] if chars_truncated else text
    lines = bounded.split("\n")
    lines_truncated = len(lines) > max_lines
    if not lines_truncated and not chars_truncated:
        return text
    visible = lines[:max_lines]
    if chars_truncated:
        return "\n".join(visible) + "\n… (more content)"
    remaining = len(lines) - max_lines
    return "\n".join(visible) + f"\n… (+{remaining} more lines)"


DETAIL_BODY_MAX_CHARS = 64 * 1024
"""Hard cap on characters rendered in the detail-pane body."""


DETAIL_BODY_MAX_LINES = 1000
"""Hard cap on lines rendered in the detail-pane body.

The detail pane wraps the body ``Static`` in a ``VerticalScroll`` so the user
can scroll within the pane. The cap exists purely as a defence against
multi-megabyte session logs that would otherwise stall ``Static.update``.
"""


def find_first_match_line(
    text: str,
    terms: cabc.Sequence[str],
    *,
    case_sensitive: bool = False,
    regex: bool = False,
) -> int | None:
    """Return the 0-based line index of the first line containing any term.

    Parameters
    ----------
    text : str
        The body to scan.
    terms : Sequence[str]
        Query terms (substring or regex) to search for. Empty → no match.
    case_sensitive : bool, default False
        When False, matching is case-folded.
    regex : bool, default False
        When False, each term is escaped before regex compilation. When True,
        each term is compiled as-is.

    Returns
    -------
    int | None
        The line index of the first match, or ``None`` if no line matches.
        Malformed regex patterns are silently skipped.
    """
    if not text or not terms:
        return None
    flags = 0 if case_sensitive else re.IGNORECASE
    patterns: list[str] = []
    for term in terms:
        if not term:
            continue
        compiled_source = term if regex else re.escape(term)
        try:
            re.compile(compiled_source, flags)
        except re.error:
            continue
        patterns.append(f"(?:{compiled_source})")
    if not patterns:
        return None
    combined = re.compile("|".join(patterns), flags)
    for idx, line in enumerate(text.split("\n")):
        if combined.search(line):
            return idx
    return None


def highlight_matches(
    text: str,
    terms: cabc.Sequence[str],
    *,
    case_sensitive: bool = False,
    regex: bool = False,
    style: str = "bold yellow",
) -> _RichText:
    """Build a Rich ``Text`` with every occurrence of any term styled.

    Stacks one ``highlight_regex`` pass per term. Literal matching is bounded
    by the text and term counts; caller-supplied regex patterns retain Python
    ``re`` complexity and must not be evaluated on a UI message pump.
    Malformed patterns are silently skipped (mirrors
    :func:`find_first_match_line`).
    """
    rich = _RichText(text, no_wrap=False)
    if not text or not terms:
        return rich
    flags = 0 if case_sensitive else re.IGNORECASE
    for term in terms:
        if not term:
            continue
        pattern_source = term if regex else re.escape(term)
        try:
            compiled = re.compile(pattern_source, flags)
        except re.error:
            continue
        rich.highlight_regex(compiled, style=style)
    return rich


ContentFormat = t.Literal["json", "markdown", "text"]
"""Detected body format for detail-pane rendering — see :func:`detect_content_format`."""


#: Structural markdown signals; any match routes a body to markdown rendering.
#: Weak/incidental markers (a single ``- `` line, ``2 ** 3``, a ``#hashtag``)
#: are intentionally excluded so a plain message keeps its literal line breaks
#: and match highlighting (see :func:`detect_content_format`).
_MARKDOWN_SIGNALS = re.compile(
    r"""
      ^```                                     # fenced code block
    | ^\#{1,6}\ \S                             # ATX heading
    | \*\*[^\s*][^*\n]*\*\*                     # **bold**
    | ^[ ]*>[ \t]\S                            # blockquote
    | \[[^\]\n]+\]\([^)\n]+\)                   # [link](url)
    | ^[ \t]*[-*+]\ \S[^\n]*\n[ \t]*[-*+]\ \S   # two-plus bullet list items
    | ^[ \t]*\d+\.\ \S[^\n]*\n[ \t]*\d+\.\ \S   # two-plus numbered list items
    | ^[ ]*\|.+\|[^\n]*\n[ ]*\|?[\s:|-]*-{2,}   # pipe table (row + separator)
    """,
    re.MULTILINE | re.VERBOSE,
)


def detect_content_format(text: str) -> ContentFormat:
    r"""Sniff the format of a record body for syntax-aware rendering.

    The decision drives whether the detail pane renders the body via
    :class:`rich.syntax.Syntax` (JSON), :class:`rich.markdown.Markdown`, or
    the existing match-highlighted :class:`rich.text.Text`. ``record.path``
    is **not** consulted because most adapters store the source file
    (``.jsonl`` / ``.sqlite``) while ``record.text`` is an extracted
    chat-message payload — the only reliable signal is the body itself.

    Markdown mode trips on a *structural* signal — a fenced code block, an
    ATX heading, ``**bold**``, a blockquote, a ``[link](url)``, a two-plus
    item bullet or numbered list, or a pipe table — because those imply the
    author wrote markdown (and reflowing the body is then expected). Weak,
    incidental markers are deliberately ignored: a single ``- `` line, a lone
    ``*``/``_``, ``2 ** 3``, or a ``#hashtag`` stay ``"text"`` so a plain
    message keeps its literal line breaks and match highlighting.

    Parameters
    ----------
    text : str
        The body to classify.

    Returns
    -------
    {"json", "markdown", "text"}
        ``"json"`` when the body parses as JSON; ``"markdown"`` on a strong
        markdown signal; ``"text"`` otherwise (also the empty-body case).

    Examples
    --------
    >>> detect_content_format('{"a": 1}')
    'json'
    >>> detect_content_format("# Heading\\n\\nbody")
    'markdown'
    >>> detect_content_format("**bold** section header\\n\\nbody")
    'markdown'
    >>> detect_content_format("plain message body")
    'text'
    >>> detect_content_format("- not really markdown")
    'text'
    """
    if not text:
        return "text"
    stripped = text.lstrip()
    if stripped.startswith(("{", "[")):
        try:
            json.loads(text)
        except RecursionError, ValueError:
            pass
        else:
            return "json"
    if _MARKDOWN_SIGNALS.search(text):
        return "markdown"
    return "text"


#: Structural signals that a body might be source code. A positive result only
#: routes the body to the detail worker, where Pygments confirms the language
#: off the message pump; it is deliberately inclusive of code and quiet on prose.
_CODE_SIGNAL = re.compile(
    r"""
      ^[ \t]*(?:import|from)\ [\w.]+                      # import x / from x
    | ^[ \t]*(?:def|class|func|fn|struct|enum|trait|impl)\ +\w  # def name / class name
    | ^[ \t]*(?:function|const|let|var)\ +\w+\s*[=(]       # function foo( / const x =
    | ^[ \t]*(?:public|private|protected|static)\ +\w     # java-ish modifiers
    | ^[ \t]*(?:package|namespace|module|use)\ +[\w:.]+   # package/module decl
    | ^\s*\#(?:include|define|pragma)\b                   # C preprocessor
    | [{};]\ *$                                            # line ends in brace/semicolon
    """,
    re.MULTILINE | re.VERBOSE,
)


def looks_like_code(text: str) -> bool:
    r"""Cheaply guess whether ``text`` might be source code (routing only).

    A pump-safe pre-filter: a positive result routes the body to the detail
    worker, where :mod:`pygments` confirms the language off the pump and a
    confidence gate rejects prose. It errs toward routing (a false positive
    only costs one off-pump guess) while leaving plain messages on the
    synchronous inline path.

    Examples
    --------
    >>> looks_like_code("import os\ndef main():\n    return 0\n")
    True
    >>> looks_like_code("how do I roll back the staging deploy")
    False
    """
    return bool(text) and _CODE_SIGNAL.search(text) is not None


#: Structural tag shapes for the :func:`looks_like_markup` gate. An open tag is
#: ``<name ...>`` (attributes optional); a close tag is ``</name>``; a
#: self-closing tag is ``<name .../>``. Names anchor on a letter so a bare ``<``
#: in prose or a ``List<int>`` generic is not a candidate.
_MARKUP_OPEN_TAG_RE = re.compile(r"<([A-Za-z][\w:.-]*)(?:\s[^<>]*?)?>")
_MARKUP_CLOSE_TAG_RE = re.compile(r"</([A-Za-z][\w:.-]*)\s*>")
_MARKUP_SELFCLOSE_TAG_RE = re.compile(r"<([A-Za-z][\w:.-]*)(?:\s[^<>]*?)?/>")


def looks_like_markup(text: str) -> bool:
    r"""Cheaply gate whether ``text`` is XML/markup-shaped (styling only).

    A structural gate, not a per-``<`` test: a body qualifies only when at least
    two *paired* structural tags are present — a matched open/close pair, two
    ``</name>`` closers, or two self-closing tags. This keeps generics and
    comparisons out (``List<int>``, ``Vec<T>``, ``a < b``, ``x > y`` all have a
    ``<`` or ``>`` but never a matched pair), so a mostly-prose body with sparse
    real tags is styled while ordinary prose is left plain. A positive result
    routes structural spans (:func:`highlight_markup_spans`) onto the body; it
    never changes the text.

    Examples
    --------
    >>> looks_like_markup("<note>hi</note>\n<warn>x</warn>")
    True
    >>> looks_like_markup("The parser builds a List<int> when a < b and x > y.")
    False
    """
    if not text or "<" not in text:
        return False
    opens = collections.Counter(m.group(1) for m in _MARKUP_OPEN_TAG_RE.finditer(text))
    closes = collections.Counter(m.group(1) for m in _MARKUP_CLOSE_TAG_RE.finditer(text))
    self_closing = sum(1 for _ in _MARKUP_SELFCLOSE_TAG_RE.finditer(text))
    paired = self_closing
    for name, close_count in closes.items():
        paired += 2 * min(opens.get(name, 0), close_count)
    return paired >= 2


@dataclasses.dataclass(frozen=True, slots=True)
class AnsiColors:
    """Semantic ANSI colors for terminal status output.

    Attributes
    ----------
    enabled : bool
        Whether :meth:`colorize` wraps text in escape codes. ``False`` returns text
        unchanged, which is how ``--color never`` and non-TTY streams render plain output.
    """

    enabled: bool

    SUCCESS: t.ClassVar[str] = "\x1b[32m"
    WARNING: t.ClassVar[str] = "\x1b[33m"
    ERROR: t.ClassVar[str] = "\x1b[31m"
    INFO: t.ClassVar[str] = "\x1b[36m"
    HEADING: t.ClassVar[str] = "\x1b[1;36m"
    HIGHLIGHT: t.ClassVar[str] = "\x1b[35m"
    MATCH: t.ClassVar[str] = "\x1b[1;31m"
    LINE_NUMBER: t.ClassVar[str] = "\x1b[32m"
    PATH: t.ClassVar[str] = "\x1b[38;5;177m"
    MUTED: t.ClassVar[str] = "\x1b[34m"
    WHITE: t.ClassVar[str] = "\x1b[37m"
    ACCENT: t.ClassVar[str] = "\x1b[38;5;179m"
    DIM: t.ClassVar[str] = "\x1b[38;5;245m"
    RESET: t.ClassVar[str] = "\x1b[0m"

    @classmethod
    def for_stream(cls, color_mode: ColorMode, stream: t.TextIO) -> AnsiColors:
        """Build semantic colors for ``stream`` and ``color_mode``."""
        return cls(enabled=should_enable_color(color_mode, stream))

    def colorize(self, text: str, color: str) -> str:
        """Apply ``color`` to ``text`` when colors are enabled."""
        if not self.enabled:
            return text
        return f"{color}{text}{self.RESET}"

    def success(self, text: str) -> str:
        """Format text as success."""
        return self.colorize(text, self.SUCCESS)

    def warning(self, text: str) -> str:
        """Format text as warning."""
        return self.colorize(text, self.WARNING)

    def error(self, text: str) -> str:
        """Format text as error."""
        return self.colorize(text, self.ERROR)

    def info(self, text: str) -> str:
        """Format text as informational."""
        return self.colorize(text, self.INFO)

    def heading(self, text: str) -> str:
        """Format text as a status heading."""
        return self.colorize(text, self.HEADING)

    def highlight(self, text: str) -> str:
        """Format text as highlighted."""
        return self.colorize(text, self.HIGHLIGHT)

    def match(self, text: str) -> str:
        """Format text as a matched span (rg-style red+bold)."""
        return self.colorize(text, self.MATCH)

    def line_number(self, text: str) -> str:
        """Format text as a line-number prefix (rg-style green)."""
        return self.colorize(text, self.LINE_NUMBER)

    def path(self, text: str) -> str:
        """Format text as a path prefix (bright purple)."""
        return self.colorize(text, self.PATH)

    def muted(self, text: str) -> str:
        """Format text as muted."""
        return self.colorize(text, self.MUTED)

    def white(self, text: str) -> str:
        """Format text as plain white."""
        return self.colorize(text, self.WHITE)

    def accent(self, text: str) -> str:
        """Format text as a warm-amber search accent."""
        return self.colorize(text, self.ACCENT)

    def dim(self, text: str) -> str:
        """Format text as dim (reduced intensity)."""
        return self.colorize(text, self.DIM)


def should_enable_color(color_mode: ColorMode, stream: t.TextIO) -> bool:
    """Return whether output written to ``stream`` should use colors."""
    if os.environ.get("NO_COLOR"):
        return False
    if color_mode == "never":
        return False
    if color_mode == "always":
        return True
    if os.environ.get("FORCE_COLOR"):
        return True
    if os.environ.get("TERM", "").lower() == "dumb":
        return False
    return bool(getattr(stream, "isatty", lambda: False)())
