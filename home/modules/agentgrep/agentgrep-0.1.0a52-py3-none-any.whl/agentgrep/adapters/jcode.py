"""jcode swarm CLI store parsers and registry fragment."""

from __future__ import annotations

import collections.abc as cabc
import typing as t

from agentgrep.adapters._common import (
    _path_like_str,
    _record_origin,
)
from agentgrep.adapters._extract import (
    build_search_record,
    candidate_from_mapping,
)
from agentgrep.adapters._registry import AnyParserSpec, ParserSpec
from agentgrep.readers import (
    as_optional_str,
    iter_jsonl,
    read_json_file,
)
from agentgrep.records import (
    SearchRecord,
    SourceHandle,
)


def parse_jcode_prompt_history(source: SourceHandle) -> cabc.Iterator[SearchRecord]:
    """Parse jcode's ``prompt-history.jsonl`` append-only prompt audit log.

    Each line is a bare JSON string -- the prompt text -- not an object, and
    carries no timestamp, session id, or cwd of its own.
    """
    for value in iter_jsonl(source.path):
        prompt = value if isinstance(value, str) else None
        if not prompt or not prompt.strip():
            continue
        yield SearchRecord(
            kind="prompt",
            agent=source.agent,
            store=source.store,
            adapter_id=source.adapter_id,
            path=source.path,
            text=prompt.strip(),
            title="jcode prompt history",
            role="user",
        )


def parse_jcode_session_file(source: SourceHandle) -> cabc.Iterator[SearchRecord]:
    """Parse one jcode ``sessions/session_<word>_<epoch_ms>_<hash>.json`` (or ``.bak``) file.

    The session object's own top-level ``id`` and per-message ``id`` collide
    (both use the key ``id``), so this walks ``messages`` explicitly with the
    session id and ``working_dir`` supplied as the message-candidate's session
    id / origin rather than delegating to the fully-recursive
    :func:`~agentgrep.adapters._extract.iter_message_candidates`, which has no
    fallback parameter for session id and would otherwise pick up each
    message's own id instead of the session's.
    """
    payload = read_json_file(source.path)
    if not isinstance(payload, dict):
        return
    session = t.cast("dict[str, object]", payload)
    session_id = as_optional_str(session.get("id")) or source.path.stem
    title = as_optional_str(session.get("title"))
    model = as_optional_str(session.get("model"))
    origin = _record_origin(cwd=_path_like_str(session.get("working_dir")))
    messages = session.get("messages")
    if not isinstance(messages, list):
        return
    for message in t.cast("list[object]", messages):
        if not isinstance(message, dict):
            continue
        candidate = candidate_from_mapping(
            t.cast("dict[str, object]", message),
            timestamp=None,
            model=model,
            session_id=session_id,
            conversation_id=session_id,
            origin=origin,
        )
        if candidate is None:
            continue
        if candidate.title is None:
            candidate.title = title
        yield build_search_record(source, candidate)


_JCODE_PARSERS: tuple[AnyParserSpec, ...] = (
    ParserSpec("jcode.prompt_history_jsonl.v1", parse_jcode_prompt_history),
    ParserSpec("jcode.sessions_json.v1", parse_jcode_session_file),
)
"""Dispatch rows for every ``jcode.*`` adapter id."""
