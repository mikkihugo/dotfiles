"""Kimi Code CLI store parsers and registry fragment."""

from __future__ import annotations

import collections.abc as cabc
import datetime
import json
import pathlib
import typing as t

from agentgrep.adapters._common import (
    _path_like_str,
    _record_origin,
)
from agentgrep.adapters._extract import (
    flatten_content_value,
)
from agentgrep.adapters._generic import (
    parse_text_store_file,
)
from agentgrep.adapters._registry import AnyParserSpec, ParserSpec, StreamParserSpec
from agentgrep.readers import (
    _iter_jsonl,
    as_optional_str,
    isoformat_from_mtime_ns,
    read_json_file,
)
from agentgrep.records import (
    JSONValue,
    RawJsonlSkipLine,
    RecordOrigin,
    SearchRecord,
    SourceHandle,
)

_SESSION_DIR_DEPTH = 3
"""``<session_dir>/agents/<agentId>/wire.jsonl`` -> 3 ``.parent`` hops to the session dir."""


def _kimi_session_dir(path: pathlib.Path) -> pathlib.Path:
    """Return the ``session_<uuid>`` directory owning a ``wire.jsonl`` path."""
    return path.parents[_SESSION_DIR_DEPTH - 1]


def _kimi_session_state(session_dir: pathlib.Path) -> dict[str, object] | None:
    """Read the sibling ``state.json`` for one Kimi Code session, if present."""
    payload = read_json_file(session_dir / "state.json")
    return t.cast("dict[str, object]", payload) if isinstance(payload, dict) else None


def _kimi_session_origin(state: dict[str, object] | None) -> RecordOrigin | None:
    """Build the ``cwd`` origin for a Kimi Code session from its ``state.json``."""
    if state is None:
        return None
    return _record_origin(cwd=_path_like_str(state.get("cwd")))


def _kimi_session_title(state: dict[str, object] | None) -> str | None:
    """Read the session title Kimi Code records in ``state.json``."""
    return as_optional_str(state.get("title")) if state is not None else None


def _kimi_events(
    source: SourceHandle,
    *,
    raw_skip_line: RawJsonlSkipLine | None,
    reverse: bool,
) -> cabc.Iterator[JSONValue]:
    if raw_skip_line is not None:
        return _iter_jsonl(
            source.path,
            skip_line=raw_skip_line,
            skip_line_mode="line",
            reverse=reverse,
        )
    return _iter_jsonl(source.path, reverse=reverse)


def parse_kimi_session_transcript(
    source: SourceHandle,
    *,
    raw_skip_line: RawJsonlSkipLine | None = None,
    reverse: bool = False,
) -> cabc.Iterator[SearchRecord]:
    """Parse the visible user/assistant transcript out of a Kimi Code ``wire.jsonl``.

    Two ``wire.jsonl`` line shapes carry conversation text agentgrep treats as
    the primary transcript: ``context.append_message`` (every user prompt,
    including injected ``<system-reminder>`` turns -- no assistant record of
    this shape was ever observed) and ``context.append_loop_event`` rows whose
    ``event.type`` is ``content.part`` with ``event.part.type == "text"`` (the
    assistant's streamed reply). Reasoning (``event.part.type == "think"``)
    and tool traffic are read by :func:`parse_kimi_tool_activity` instead, so
    this transcript stays free of tool payloads the way ``grok.sessions``
    excludes reasoning summaries.
    """
    session_dir = _kimi_session_dir(source.path)
    agent_id = source.path.parent.name
    conversation_id = session_dir.name
    state = _kimi_session_state(session_dir)
    origin = _kimi_session_origin(state)
    title = _kimi_session_title(state)
    fallback_timestamp = isoformat_from_mtime_ns(source.mtime_ns)
    for event in _kimi_events(source, raw_skip_line=raw_skip_line, reverse=reverse):
        if not isinstance(event, dict):
            continue
        mapping = t.cast("dict[str, object]", event)
        event_type = mapping.get("type")
        timestamp = _kimi_millis_to_isoformat(mapping.get("time")) or fallback_timestamp
        if event_type == "context.append_message":
            message = mapping.get("message")
            if not isinstance(message, dict):
                continue
            message_mapping = t.cast("dict[str, object]", message)
            role = as_optional_str(message_mapping.get("role"))
            text = flatten_content_value(t.cast("JSONValue | None", message_mapping.get("content")))
            if not role or not text:
                continue
            yield SearchRecord(
                kind="prompt" if role == "user" else "history",
                agent=source.agent,
                store=source.store,
                adapter_id=source.adapter_id,
                path=source.path,
                text=text,
                title=title,
                role=role,
                timestamp=timestamp,
                session_id=conversation_id,
                conversation_id=conversation_id,
                origin=origin,
                metadata={"agent_id": agent_id} if agent_id != "main" else {},
            )
        elif event_type == "context.append_loop_event":
            loop_event = mapping.get("event")
            if not isinstance(loop_event, dict):
                continue
            loop_mapping = t.cast("dict[str, object]", loop_event)
            if loop_mapping.get("type") != "content.part":
                continue
            part = loop_mapping.get("part")
            if not isinstance(part, dict):
                continue
            part_mapping = t.cast("dict[str, object]", part)
            if part_mapping.get("type") != "text":
                continue
            text = as_optional_str(part_mapping.get("text"))
            if not text:
                continue
            yield SearchRecord(
                kind="history",
                agent=source.agent,
                store=source.store,
                adapter_id=source.adapter_id,
                path=source.path,
                text=text,
                title=title,
                role="assistant",
                timestamp=timestamp,
                session_id=conversation_id,
                conversation_id=conversation_id,
                origin=origin,
                metadata={"agent_id": agent_id} if agent_id != "main" else {},
            )


def parse_kimi_tool_activity(
    source: SourceHandle,
    *,
    raw_skip_line: RawJsonlSkipLine | None = None,
    reverse: bool = False,
) -> cabc.Iterator[SearchRecord]:
    """Parse tool calls, tool results, and reasoning out of a Kimi Code ``wire.jsonl``.

    ``event.type == "tool.result"`` is where a live incident string (a leaked
    IP, a suspicious hostname a shell command printed) most often first shows
    up, since it is the raw text a command or MCP tool returned.
    """
    session_dir = _kimi_session_dir(source.path)
    agent_id = source.path.parent.name
    conversation_id = session_dir.name
    state = _kimi_session_state(session_dir)
    origin = _kimi_session_origin(state)
    title = _kimi_session_title(state)
    fallback_timestamp = isoformat_from_mtime_ns(source.mtime_ns)
    for event in _kimi_events(source, raw_skip_line=raw_skip_line, reverse=reverse):
        if not isinstance(event, dict):
            continue
        mapping = t.cast("dict[str, object]", event)
        if mapping.get("type") != "context.append_loop_event":
            continue
        loop_event = mapping.get("event")
        if not isinstance(loop_event, dict):
            continue
        loop_mapping = t.cast("dict[str, object]", loop_event)
        loop_type = loop_mapping.get("type")
        timestamp = _kimi_millis_to_isoformat(mapping.get("time")) or fallback_timestamp
        text: str | None = None
        role = "tool"
        metadata: dict[str, object] = {}
        if agent_id != "main":
            metadata["agent_id"] = agent_id
        if loop_type == "tool.call":
            name = as_optional_str(loop_mapping.get("name"))
            args = loop_mapping.get("args")
            args_text = json.dumps(args, default=str, sort_keys=True) if args else ""
            text = f"{name}({args_text})" if name else args_text or None
            if name:
                metadata["tool_name"] = name
        elif loop_type == "tool.result":
            result = loop_mapping.get("result")
            if isinstance(result, dict):
                text = as_optional_str(t.cast("dict[str, object]", result).get("output"))
        elif loop_type == "content.part":
            part = loop_mapping.get("part")
            if isinstance(part, dict):
                part_mapping = t.cast("dict[str, object]", part)
                if part_mapping.get("type") == "think":
                    text = as_optional_str(part_mapping.get("think"))
                    role = "assistant"
                    metadata["reasoning"] = True
        if not text:
            continue
        call_id = as_optional_str(loop_mapping.get("toolCallId"))
        if call_id:
            metadata["tool_call_id"] = call_id
        yield SearchRecord(
            kind="history",
            agent=source.agent,
            store=source.store,
            adapter_id=source.adapter_id,
            path=source.path,
            text=text,
            title=title,
            role=role,
            timestamp=timestamp,
            session_id=conversation_id,
            conversation_id=conversation_id,
            origin=origin,
            metadata=metadata,
        )


def _kimi_millis_to_isoformat(value: object) -> str | None:
    """Convert Kimi Code's unix-millisecond ``time`` field to ISO-8601 UTC."""
    if isinstance(value, bool) or not isinstance(value, (int, float)) or value <= 0:
        return None
    try:
        return (
            datetime.datetime.fromtimestamp(value / 1000, tz=datetime.UTC)
            .isoformat()
            .replace("+00:00", "Z")
        )
    except (ValueError, OSError, OverflowError):
        return None


_KIMI_CODE_PARSERS: tuple[AnyParserSpec, ...] = (
    StreamParserSpec("kimi_code.sessions_jsonl.v1", parse_kimi_session_transcript),
    StreamParserSpec("kimi_code.tool_activity_jsonl.v1", parse_kimi_tool_activity),
    ParserSpec("kimi_code.tool_result_text.v1", parse_text_store_file),
    ParserSpec("kimi_code.task_output_text.v1", parse_text_store_file),
)
"""Dispatch rows for every ``kimi_code.*`` adapter id."""
