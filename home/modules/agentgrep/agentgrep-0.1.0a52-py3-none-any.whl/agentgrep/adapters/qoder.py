"""Qoder CLI/IDE store parsers and registry fragment."""

from __future__ import annotations

import collections.abc as cabc

from agentgrep.adapters._extract import (
    build_search_record,
    iter_message_candidates,
)
from agentgrep.adapters._registry import AnyParserSpec, StreamParserSpec
from agentgrep.readers import (
    _iter_jsonl,
)
from agentgrep.records import (
    RawJsonlSkipLine,
    SearchRecord,
    SourceHandle,
)



def parse_qoder_session_file(
    source: SourceHandle,
    *,
    raw_skip_line: RawJsonlSkipLine | None = None,
    reverse: bool = False,
) -> cabc.Iterator[SearchRecord]:
    """Parse a Qoder CLI ``~/.qoder/projects/<dash-encoded-cwd>/<uuid>.jsonl`` transcript.

    Each line already carries ``sessionId`` and (on conversational lines)
    ``cwd`` directly -- unlike Grok or Cursor CLI, no directory-name decode is
    needed. The shape otherwise mirrors ``claude.projects`` closely enough
    that the generic :func:`~agentgrep.adapters._extract.iter_message_candidates`
    walk handles it without a bespoke field reader.
    """
    conversation_id = source.path.stem
    seen: set[tuple[str | None, str, str | None, str | None]] = set()
    events = (
        _iter_jsonl(
            source.path,
            skip_line=raw_skip_line,
            skip_line_mode="line",
            reverse=reverse,
        )
        if raw_skip_line is not None
        else _iter_jsonl(source.path, reverse=reverse)
    )
    for event in events:
        for candidate in iter_message_candidates(event, fallback_conversation_id=conversation_id):
            key = (candidate.role, candidate.text, candidate.timestamp, candidate.conversation_id)
            if key in seen:
                continue
            seen.add(key)
            yield build_search_record(source, candidate)


def parse_qoder_conversation_history_file(
    source: SourceHandle,
    *,
    raw_skip_line: RawJsonlSkipLine | None = None,
    reverse: bool = False,
) -> cabc.Iterator[SearchRecord]:
    """Parse a Qoder IDE ``conversation-history/<id>/<id>.jsonl`` chat log.

    Lines are ``{"role": "user"|"assistant", "message": {"content": [...]}}``
    with no per-line session id or cwd. The parent directory name doubles as
    the conversation id -- ``<hash8>`` project-directory suffixes did not
    match md5/sha1/sha256 of the absolute project path in a quick check, so no
    ``cwd`` origin is recovered here.
    """
    conversation_id = source.path.parent.name
    events = (
        _iter_jsonl(
            source.path,
            skip_line=raw_skip_line,
            skip_line_mode="line",
            reverse=reverse,
        )
        if raw_skip_line is not None
        else _iter_jsonl(source.path, reverse=reverse)
    )
    for event in events:
        for candidate in iter_message_candidates(event, fallback_conversation_id=conversation_id):
            yield build_search_record(source, candidate)


_QODER_PARSERS: tuple[AnyParserSpec, ...] = (
    StreamParserSpec("qoder.sessions_jsonl.v1", parse_qoder_session_file),
    StreamParserSpec("qoder.conversation_history_jsonl.v1", parse_qoder_conversation_history_file),
)
"""Dispatch rows for every ``qoder.*`` adapter id."""
