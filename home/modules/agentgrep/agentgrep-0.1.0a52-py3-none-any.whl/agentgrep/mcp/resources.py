"""Static and templated MCP resources for ``agentgrep``."""

from __future__ import annotations

import json
import pathlib
import typing as t

from mcp.types import ResourceTemplateReference

from agentgrep.mcp._library import (
    KNOWN_ADAPTERS,
    READONLY_TAGS,
    AgentSelector,
    agentgrep,
    normalize_agent_selection,
)
from agentgrep.mcp.models import (
    BackendAvailabilityModel,
    CapabilitiesModel,
    SourceListAdapter,
    SourceRecordModel,
)
from agentgrep.store_catalog import CATALOG
from agentgrep.stores import StoreFormat, StoreRole

if t.TYPE_CHECKING:
    from fastmcp import FastMCP

#: One-line descriptions for each :class:`StoreRole` value. Kept here rather
#: than on the enum so the wording can be tuned for MCP consumers without
#: touching the library surface.
_ROLE_DESCRIPTIONS: dict[str, str] = {
    "primary_chat": "Primary conversation transcript for an agent.",
    "supplementary_chat": "Secondary chat (e.g. composer, side panel).",
    "prompt_history": "User-issued prompt history outside a session log.",
    "persistent_memory": "Cross-session memory or notes the agent retains.",
    "plan": "Plan-style step list the agent generated or maintains.",
    "todo": "Task list or todo store driven by the agent.",
    "instruction": "Instruction, rules, skill, or plugin material that steers an agent.",
    "app_state": "Application state (settings, UI, caches that aren't chat).",
    "cache": "Throwaway caches; usually not search-by-default.",
    "source_tree": "Source-tree snapshot or workspace index.",
    "unknown": "Role not yet classified.",
}

#: One-line descriptions for each :class:`StoreFormat` value.
_FORMAT_DESCRIPTIONS: dict[str, str] = {
    "jsonl": "JSON Lines: one object per line.",
    "json_array": "Single JSON array of records.",
    "json_object": "Single JSON object holding records at known keys.",
    "sqlite": "SQLite database opened read-only.",
    "text": "Plain text or Markdown file.",
    "md_frontmatter": "Markdown with YAML/JSON frontmatter blocks.",
    "protobuf": "Binary protobuf payload.",
    "opaque": "Format not parsed by agentgrep.",
}


def list_source_models(agent: AgentSelector = "all") -> list[SourceRecordModel]:
    """Return discovered sources as typed MCP payloads."""
    backends = agentgrep.select_backends()
    sources = agentgrep.discover_sources(
        pathlib.Path.home(),
        normalize_agent_selection(agent),
        backends,
    )
    return [SourceRecordModel.from_source(source) for source in sources]


def _backend_name(path: str | None) -> str | None:
    """Return a selected executable's name without its machine-local path."""
    return None if path is None else pathlib.Path(path).name


def build_capabilities() -> CapabilitiesModel:
    """Build a typed capability summary."""
    backends = agentgrep.select_backends()
    return CapabilitiesModel(
        agents=list(agentgrep.AGENT_CHOICES),
        search_scopes=["prompts", "conversations", "all"],
        adapters=list(KNOWN_ADAPTERS),
        tools=[
            "search",
            "recent_sessions",
            "find",
            "list_sources",
            "filter_sources",
            "summarize_discovery",
            "list_stores",
            "get_store_descriptor",
            "inspect_record_sample",
            "inspect_result",
            "validate_query",
        ],
        resources=[
            "agentgrep://capabilities",
            "agentgrep://sources",
            "agentgrep://sources/{agent}",
            "agentgrep://catalog",
            "agentgrep://query-language",
            "agentgrep://store-roles",
            "agentgrep://store-formats",
        ],
        prompts=["search_prompts", "search_conversations", "inspect_stores"],
        backends=BackendAvailabilityModel(
            find_tool=_backend_name(backends.find_tool),
            grep_tool=_backend_name(backends.grep_tool),
            json_tool=_backend_name(backends.json_tool),
        ),
    )


def register_completions(mcp: FastMCP) -> None:
    """Answer argument completion for ``agentgrep://sources/{agent}``.

    The parameter is a closed set, but MCP publishes a template's URI and
    never its parameter domain -- ``resources/templates/list`` carries no
    schema at all -- so completion is the only wire path by which a client
    can learn the valid agent names.

    Serves human-facing hosts; no agent CLI sends the request.
    """

    @mcp.completion
    def complete_agent(
        ref: t.Any,
        argument: t.Any,
        context: t.Any,
    ) -> list[str] | None:
        """Return the agent names matching what has been typed."""
        if not isinstance(ref, ResourceTemplateReference):
            return None
        if argument.name != "agent":
            return None
        prefix = argument.value or ""
        return [name for name in t.get_args(AgentSelector) if name.startswith(prefix)]


def register_resources(mcp: FastMCP) -> None:
    """Register every ``agentgrep`` resource on ``mcp``."""

    @mcp.resource(
        "agentgrep://capabilities",
        name="agentgrep_capabilities",
        description="Read-only capability summary for the agentgrep MCP server.",
        mime_type="application/json",
        tags=READONLY_TAGS | {"capabilities"},
    )
    def capabilities_resource() -> str:
        return build_capabilities().model_dump_json(indent=2)

    _ = capabilities_resource

    @mcp.resource(
        "agentgrep://sources",
        name="agentgrep_sources",
        description="All discovered read-only agent stores known to agentgrep.",
        mime_type="application/json",
        tags=READONLY_TAGS | {"discovery"},
    )
    def sources_resource() -> str:
        return SourceListAdapter.dump_json(list_source_models()).decode("utf-8")

    _ = sources_resource

    @mcp.resource(
        "agentgrep://sources/{agent}",
        name="agentgrep_sources_by_agent",
        description="Discovered sources filtered to one agent.",
        mime_type="application/json",
        tags=READONLY_TAGS | {"discovery"},
    )
    def sources_by_agent_resource(agent: AgentSelector) -> str:
        return SourceListAdapter.dump_json(list_source_models(agent)).decode("utf-8")

    _ = sources_by_agent_resource

    @mcp.resource(
        "agentgrep://catalog",
        name="agentgrep_catalog",
        description="Full StoreCatalog: every known store with role, format, and notes.",
        mime_type="application/json",
        tags=READONLY_TAGS | {"catalog"},
    )
    def catalog_resource() -> str:
        return CATALOG.model_dump_json(indent=2)

    _ = catalog_resource

    @mcp.resource(
        "agentgrep://query-language",
        name="agentgrep_query_language",
        description="Query-language field and operator catalog for search terms.",
        mime_type="application/json",
        tags=READONLY_TAGS | {"query"},
    )
    def query_language_resource() -> str:
        from agentgrep.query.help import (
            query_language_fields,
            query_language_operators,
            query_language_summary,
        )

        payload = {
            "summary": query_language_summary(),
            "fields": [
                {
                    "name": field.name,
                    "kind": field.kind,
                    "layer": field.layer,
                    "aliases": list(field.aliases),
                    "enum_values": list(field.enum_values),
                    "supports_comparison": field.supports_comparison,
                    "supports_range": field.supports_range,
                }
                for field in query_language_fields()
            ],
            "operators": [
                {
                    "syntax": operator.syntax,
                    "description": operator.description,
                    "example": operator.example,
                }
                for operator in query_language_operators()
            ],
        }
        return json.dumps(payload, indent=2)

    _ = query_language_resource

    @mcp.resource(
        "agentgrep://store-roles",
        name="agentgrep_store_roles",
        description="StoreRole enum members with one-line descriptions.",
        mime_type="application/json",
        tags=READONLY_TAGS | {"catalog"},
    )
    def store_roles_resource() -> str:
        rows = [
            {"name": role.name, "value": role.value, "description": _ROLE_DESCRIPTIONS[role.value]}
            for role in StoreRole
        ]
        return json.dumps(rows, indent=2)

    _ = store_roles_resource

    @mcp.resource(
        "agentgrep://store-formats",
        name="agentgrep_store_formats",
        description="StoreFormat enum members with one-line descriptions.",
        mime_type="application/json",
        tags=READONLY_TAGS | {"catalog"},
    )
    def store_formats_resource() -> str:
        rows = [
            {
                "name": fmt.name,
                "value": fmt.value,
                "description": _FORMAT_DESCRIPTIONS[fmt.value],
            }
            for fmt in StoreFormat
        ]
        return json.dumps(rows, indent=2)

    _ = store_formats_resource
