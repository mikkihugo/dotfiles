"""antigravity_cli store descriptors for the agentgrep catalogue."""

from __future__ import annotations

from agentgrep.store_catalog._common import _ANTIGRAVITY_CLI_OBSERVED_AT
from agentgrep.stores import (
    DiscoverySpec,
    StoreCoverage,
    StoreDescriptor,
    StoreFormat,
    StoreRole,
)

_ANTIGRAVITY_CLI_OBSERVED_VERSION = "agy v1.2.1"
"""App version the antigravity-cli rows below were verified against.

The observation date lives in ``observed_at`` alone. Repeating it here
is how one row drifted to a date its own module constant disagreed with.
``observations/`` records the store shapes seen at this version.
"""


_ANTIGRAVITY_CLI_STORES: tuple[StoreDescriptor, ...] = (
    StoreDescriptor(
        agent="antigravity-cli",
        store_id="antigravity-cli.history",
        role=StoreRole.PROMPT_HISTORY,
        format=StoreFormat.JSONL,
        path_pattern="${HOME}/.gemini/antigravity-cli/history.jsonl",
        observed_version=_ANTIGRAVITY_CLI_OBSERVED_VERSION,
        observed_at=_ANTIGRAVITY_CLI_OBSERVED_AT,
        schema_notes=(
            "JSONL prompt recall log. Observed keys: `display` (prompt text), "
            "`timestamp` (Unix milliseconds), `workspace`, optional `type`, "
            "and optional `conversationId`."
        ),
        sample_record=(
            '{"display":"<redacted>","timestamp":1780142400000,'
            '"type":"prompt","workspace":"/repo","conversationId":"..."}'
        ),
        search_by_default=True,
        search_notes=(
            "Default-searchable user prompt history. Full transcript stores "
            "are protobuf and remain inspectable only."
        ),
        discovery=(
            DiscoverySpec(
                store="antigravity-cli.history",
                adapter_id="antigravity_cli.history_jsonl.v1",
                data_version="antigravity_cli.history_jsonl.v1",
                path_kind="history_file",
                source_kind="jsonl",
                files=("history.jsonl",),
            ),
        ),
    ),
    StoreDescriptor(
        agent="antigravity-cli",
        store_id="antigravity-cli.conversations",
        role=StoreRole.PRIMARY_CHAT,
        format=StoreFormat.SQLITE,
        path_pattern="${HOME}/.gemini/antigravity-cli/conversations/<conversation_uuid>.db",
        observed_version=_ANTIGRAVITY_CLI_OBSERVED_VERSION,
        observed_at=_ANTIGRAVITY_CLI_OBSERVED_AT,
        schema_notes=(
            "One SQLite database per conversation. Table `steps` contains "
            "`idx`, `step_type`, `status`, `has_subtrajectory`, `metadata`, "
            "`error_details`, `permissions`, `task_details`, `render_info`, "
            "`step_payload` (mostly protobuf blobs), and `step_format`; "
            "companion metadata tables hold protobuf blobs. No public schema "
            "is available, so agentgrep extracts readable protobuf strings "
            "best-effort."
        ),
        sample_record="steps(idx=1, step_payload=<protobuf>, step_format=1)",
        distinguishes_from=("antigravity-cli.history",),
        search_by_default=False,
        search_notes="Inspectable only; protobuf transcripts are not searched by default.",
        discovery=(
            DiscoverySpec(
                store="antigravity-cli.conversations",
                adapter_id="antigravity_cli.conversations_sqlite_protobuf.v1",
                data_version="antigravity_cli.conversations_sqlite_protobuf.v1",
                path_kind="sqlite_db",
                source_kind="sqlite",
                home_subpath=("conversations",),
                glob="*.db",
            ),
        ),
    ),
    StoreDescriptor(
        agent="antigravity-cli",
        store_id="antigravity-cli.transcript",
        role=StoreRole.SUPPLEMENTARY_CHAT,
        format=StoreFormat.JSONL,
        path_pattern=(
            "${HOME}/.gemini/antigravity-cli/brain/<conversation_uuid>/"
            ".system_generated/logs/transcript_full.jsonl"
        ),
        observed_version=_ANTIGRAVITY_CLI_OBSERVED_VERSION,
        observed_at=_ANTIGRAVITY_CLI_OBSERVED_AT,
        schema_notes=(
            "Readable JSONL transcript log under a brain conversation's "
            "`.system_generated/logs/`. Each line is a step record with a "
            "universal `step_index` plus `type`, `source`, `status`, "
            "`created_at`. agentgrep surfaces the string `content` "
            "(user/assistant turns); lines without `content` — "
            "`thinking`/`tool_calls`-only lines (e.g. `PLANNER_RESPONSE`) and "
            "payload-less lines (e.g. `CONVERSATION_HISTORY`) — yield no "
            "record. This is the "
            "readable counterpart to the opaque protobuf "
            "`antigravity-cli.conversations` and reaches text the brain "
            "Markdown glob cannot. The truncated `transcript.jsonl` sibling is "
            "skipped in favour of `transcript_full.jsonl`."
        ),
        distinguishes_from=("antigravity-cli.conversations", "antigravity-cli.brain"),
        coverage=StoreCoverage.INSPECTABLE,
        search_by_default=False,
        discovery=(
            DiscoverySpec(
                store="antigravity-cli.transcript",
                adapter_id="antigravity_cli.transcript_jsonl.v1",
                path_kind="session_file",
                source_kind="jsonl",
                home_subpath=("brain",),
                glob="**/transcript_full.jsonl",
            ),
        ),
    ),
    StoreDescriptor(
        agent="antigravity-cli",
        store_id="antigravity-cli.implicit",
        role=StoreRole.SUPPLEMENTARY_CHAT,
        format=StoreFormat.PROTOBUF,
        path_pattern="${HOME}/.gemini/antigravity-cli/implicit/<conversation_uuid>.pb",
        observed_version=_ANTIGRAVITY_CLI_OBSERVED_VERSION,
        observed_at=_ANTIGRAVITY_CLI_OBSERVED_AT,
        schema_notes=(
            "Implicit/background conversation captures as loose `.pb` files. "
            "The observed payloads are high-entropy with no extractable UTF-8 "
            "runs, no protobuf field framing, and are not gzip/zlib — they "
            "appear encrypted or custom-encoded, so agentgrep cannot read "
            "them. The encryption is on the loose `.pb` file, not on protobuf: "
            "the protobuf blobs stored inside `antigravity-cli.conversations` "
            "SQLite rows still decode. Documented location only; unsupported "
            "for search."
        ),
        distinguishes_from=("antigravity-cli.conversations",),
        coverage=StoreCoverage.CATALOG_ONLY,
        search_by_default=False,
    ),
    StoreDescriptor(
        agent="antigravity-cli",
        store_id="antigravity-cli.brain",
        role=StoreRole.PLAN,
        format=StoreFormat.TEXT,
        path_pattern="${HOME}/.gemini/antigravity-cli/brain/**/*.md",
        observed_version=_ANTIGRAVITY_CLI_OBSERVED_VERSION,
        observed_at=_ANTIGRAVITY_CLI_OBSERVED_AT,
        schema_notes="Markdown planning and memory artifacts, not prompt recall.",
        search_by_default=False,
        search_notes="Inspectable only; not searched by default.",
        discovery=(
            DiscoverySpec(
                store="antigravity-cli.brain",
                adapter_id="antigravity_cli.brain_text.v1",
                data_version="antigravity_cli.brain_text.v1",
                path_kind="store_file",
                source_kind="text",
                home_subpath=("brain",),
                glob="**/*.md",
            ),
        ),
    ),
    StoreDescriptor(
        agent="antigravity-cli",
        store_id="antigravity-cli.skills",
        role=StoreRole.INSTRUCTION,
        format=StoreFormat.MARKDOWN_FRONTMATTER,
        path_pattern="${HOME}/.gemini/config/skills/<name>/SKILL.md",
        observed_version=_ANTIGRAVITY_CLI_OBSERVED_VERSION,
        observed_at=_ANTIGRAVITY_CLI_OBSERVED_AT,
        schema_notes=(
            "`SKILL.md` files with YAML frontmatter (`name`, `description`) under "
            "`skills/<name>/`. agy's binary names this directory as where it "
            "loads skills from; it did not exist when observed."
        ),
        sample_record="---\nname: <skill>\ndescription: <redacted>\n---\n<instructions>",
        coverage=StoreCoverage.CATALOG_ONLY,
        search_by_default=False,
    ),
    StoreDescriptor(
        agent="antigravity-cli",
        store_id="antigravity-cli.cache",
        role=StoreRole.CACHE,
        format=StoreFormat.JSON_OBJECT,
        path_pattern="${HOME}/.gemini/antigravity-cli/cache/",
        observed_version=_ANTIGRAVITY_CLI_OBSERVED_VERSION,
        observed_at=_ANTIGRAVITY_CLI_OBSERVED_AT,
        schema_notes="Runtime cache files. Cache state, not conversation history.",
        search_by_default=False,
    ),
    StoreDescriptor(
        agent="antigravity-cli",
        store_id="antigravity-cli.log",
        role=StoreRole.APP_STATE,
        format=StoreFormat.TEXT,
        path_pattern="${HOME}/.gemini/antigravity-cli/log/",
        observed_version=_ANTIGRAVITY_CLI_OBSERVED_VERSION,
        observed_at=_ANTIGRAVITY_CLI_OBSERVED_AT,
        schema_notes="Application logs. Diagnostics, not chat content.",
        search_by_default=False,
    ),
    StoreDescriptor(
        agent="antigravity-cli",
        store_id="antigravity-cli.oauth",
        role=StoreRole.APP_STATE,
        format=StoreFormat.OPAQUE,
        path_pattern="${HOME}/.gemini/antigravity-cli/antigravity-oauth-token",
        observed_version=_ANTIGRAVITY_CLI_OBSERVED_VERSION,
        observed_at=_ANTIGRAVITY_CLI_OBSERVED_AT,
        schema_notes="OAuth token material. Documented but never enumerated.",
        coverage=StoreCoverage.PRIVATE,
        search_by_default=False,
    ),
    StoreDescriptor(
        agent="antigravity-cli",
        store_id="antigravity-cli.gh_skills",
        role=StoreRole.INSTRUCTION,
        format=StoreFormat.MARKDOWN_FRONTMATTER,
        path_pattern="${HOME}/.gemini/antigravity-cli/skills/<skill>/SKILL.md",
        observed_version=_ANTIGRAVITY_CLI_OBSERVED_VERSION,
        observed_at=_ANTIGRAVITY_CLI_OBSERVED_AT,
        schema_notes=(
            "`SKILL.md` files placed by `gh skill install`, carrying provenance "
            "`metadata` (`github-repo`, `github-ref`, `github-tree-sha`). agy's "
            "binary never names this directory, so it is not where agy loads skills "
            "from."
        ),
        sample_record="---\nname: <skill>\ndescription: <redacted>\n---\n<instructions>",
        distinguishes_from=("antigravity-cli.skills",),
        coverage=StoreCoverage.CATALOG_ONLY,
        search_by_default=False,
    ),
    StoreDescriptor(
        agent="antigravity-cli",
        store_id="antigravity-cli.plugins",
        role=StoreRole.INSTRUCTION,
        format=StoreFormat.MARKDOWN_FRONTMATTER,
        path_pattern="${HOME}/.gemini/config/plugins/<plugin>/skills/<skill>/SKILL.md",
        observed_version=_ANTIGRAVITY_CLI_OBSERVED_VERSION,
        observed_at=_ANTIGRAVITY_CLI_OBSERVED_AT,
        schema_notes=(
            "Installed agy plugins, one directory each holding `plugin.json`, a "
            "`README.md`, and `skills/<skill>/SKILL.md`; some add `references/` or "
            "`scripts/`. Instruction Markdown, not history."
        ),
        distinguishes_from=("antigravity-cli.skills",),
        coverage=StoreCoverage.CATALOG_ONLY,
        search_by_default=False,
    ),
    StoreDescriptor(
        agent="antigravity-cli",
        store_id="antigravity-cli.config",
        role=StoreRole.APP_STATE,
        format=StoreFormat.JSON_OBJECT,
        path_pattern="${HOME}/.gemini/config/config.json",
        observed_version=_ANTIGRAVITY_CLI_OBSERVED_VERSION,
        observed_at=_ANTIGRAVITY_CLI_OBSERVED_AT,
        schema_notes=(
            "agy configuration in the `~/.gemini/config/` directory, which Gemini "
            "CLI has no use for."
        ),
        coverage=StoreCoverage.CATALOG_ONLY,
        search_by_default=False,
    ),
    StoreDescriptor(
        agent="antigravity-cli",
        store_id="antigravity-cli.import_manifest",
        role=StoreRole.APP_STATE,
        format=StoreFormat.JSON_OBJECT,
        path_pattern="${HOME}/.gemini/config/import_manifest.json",
        observed_version=_ANTIGRAVITY_CLI_OBSERVED_VERSION,
        observed_at=_ANTIGRAVITY_CLI_OBSERVED_AT,
        schema_notes=("An `imports` list. agy's binary names the file and Gemini CLI's does not."),
        coverage=StoreCoverage.CATALOG_ONLY,
        search_by_default=False,
    ),
    StoreDescriptor(
        agent="antigravity-cli",
        store_id="antigravity-cli.mcp_config",
        role=StoreRole.APP_STATE,
        format=StoreFormat.JSON_OBJECT,
        path_pattern="${HOME}/.gemini/config/mcp_config.json",
        observed_version=_ANTIGRAVITY_CLI_OBSERVED_VERSION,
        observed_at=_ANTIGRAVITY_CLI_OBSERVED_AT,
        schema_notes=(
            "agy's MCP server configuration. Server entries can carry `env` values, "
            "and tools that rewrite the file leave `mcp_config.json.bak.*` copies "
            "beside it."
        ),
        coverage=StoreCoverage.CATALOG_ONLY,
        search_by_default=False,
    ),
    StoreDescriptor(
        agent="antigravity-cli",
        store_id="antigravity-cli.mcp_tools",
        role=StoreRole.CACHE,
        format=StoreFormat.JSON_OBJECT,
        path_pattern="${HOME}/.gemini/antigravity-cli/mcp/<server>/<tool>.json",
        observed_version=_ANTIGRAVITY_CLI_OBSERVED_VERSION,
        observed_at=_ANTIGRAVITY_CLI_OBSERVED_AT,
        schema_notes=(
            "agy's cache of MCP tool definitions: a directory per configured "
            "server holding one `{name, description, parameters}` file per "
            "tool. Tool schemas, not conversation content."
        ),
        distinguishes_from=("antigravity-cli.mcp_config",),
        coverage=StoreCoverage.CATALOG_ONLY,
        search_by_default=False,
    ),
)
