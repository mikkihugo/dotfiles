"""antigravity_ide store descriptors for the agentgrep catalogue."""

from __future__ import annotations

from agentgrep.store_catalog._common import _ANTIGRAVITY_IDE_OBSERVED_AT
from agentgrep.stores import (
    DiscoverySpec,
    StoreCoverage,
    StoreDescriptor,
    StoreFormat,
    StoreRole,
)

_ANTIGRAVITY_IDE_OBSERVED_VERSION = "Antigravity 1.104.0"
"""App version the antigravity-ide rows below were verified against.

The observation date lives in ``observed_at`` alone. Repeating it here
is how one row drifted to a date its own module constant disagreed with.
``observations/`` records the store shapes seen at this version.

The observer reads no version for the desktop app, so its manifest is
``unknown.toml``. This one comes from the ``product.json`` of the WSL
remote-server build under ``~/.antigravity-server/bin/``, the build that
last wrote the stores below. The Windows app installed beside it is
Antigravity IDE 2.5.5 (VS Code 1.107.0); it keeps its own
``.gemini/antigravity`` tree on the Windows side, which these rows do not
cover.
"""


_ANTIGRAVITY_IDE_STORES: tuple[StoreDescriptor, ...] = (
    StoreDescriptor(
        agent="antigravity-ide",
        store_id="antigravity-ide.conversations",
        role=StoreRole.PRIMARY_CHAT,
        format=StoreFormat.PROTOBUF,
        path_pattern="${HOME}/.gemini/antigravity/conversations/<conversation_uuid>.pb",
        observed_version=_ANTIGRAVITY_IDE_OBSERVED_VERSION,
        observed_at=_ANTIGRAVITY_IDE_OBSERVED_AT,
        schema_notes=(
            "Per-conversation transcripts as loose `.pb` files. The observed "
            "payloads are high-entropy with no extractable UTF-8 runs, no "
            "protobuf field framing, and are not gzip/zlib — they appear "
            "encrypted or custom-encoded, so agentgrep cannot read them. The "
            "encryption is on the loose `.pb` file, not on protobuf: the "
            "sibling `user_settings.pb` is plaintext protobuf, and the "
            "protobuf blobs inside `antigravity-cli.conversations` SQLite rows "
            "still decode. Documented location only; unsupported for search."
        ),
        coverage=StoreCoverage.CATALOG_ONLY,
        search_by_default=False,
    ),
    StoreDescriptor(
        agent="antigravity-ide",
        store_id="antigravity-ide.implicit",
        role=StoreRole.SUPPLEMENTARY_CHAT,
        format=StoreFormat.PROTOBUF,
        path_pattern="${HOME}/.gemini/antigravity/implicit/<conversation_uuid>.pb",
        observed_version=_ANTIGRAVITY_IDE_OBSERVED_VERSION,
        observed_at=_ANTIGRAVITY_IDE_OBSERVED_AT,
        schema_notes=(
            "Implicit/background conversation captures as loose `.pb` files, "
            "with the same high-entropy, apparently-encrypted payload shape as "
            "`antigravity-ide.conversations`. Documented location only; "
            "unsupported for search."
        ),
        distinguishes_from=("antigravity-ide.conversations",),
        coverage=StoreCoverage.CATALOG_ONLY,
        search_by_default=False,
    ),
    StoreDescriptor(
        agent="antigravity-ide",
        store_id="antigravity-ide.brain",
        role=StoreRole.PLAN,
        format=StoreFormat.TEXT,
        path_pattern="${HOME}/.gemini/antigravity/brain/**/*.md",
        observed_version=_ANTIGRAVITY_IDE_OBSERVED_VERSION,
        observed_at=_ANTIGRAVITY_IDE_OBSERVED_AT,
        schema_notes="Markdown planning and memory artifacts, not prompt recall.",
        search_by_default=False,
        search_notes="Inspectable only; not searched by default.",
        discovery=(
            DiscoverySpec(
                store="antigravity-ide.brain",
                adapter_id="antigravity_ide.brain_text.v1",
                data_version="antigravity_ide.brain_text.v1",
                path_kind="store_file",
                source_kind="text",
                home_subpath=("brain",),
                glob="**/*.md",
            ),
        ),
    ),
    StoreDescriptor(
        agent="antigravity-ide",
        store_id="antigravity-ide.brain_resolved",
        role=StoreRole.PLAN,
        format=StoreFormat.TEXT,
        path_pattern="${HOME}/.gemini/antigravity/brain/<uuid>/task.md.resolved",
        observed_version=_ANTIGRAVITY_IDE_OBSERVED_VERSION,
        observed_at=_ANTIGRAVITY_IDE_OBSERVED_AT,
        schema_notes=(
            "Expanded task Markdown (`task.md.resolved` plus numbered "
            "`.resolved.0..N` snapshots) that the `**/*.md` brain glob cannot "
            "reach because of the `.resolved` suffix. Readable plan text, "
            "inspectable opt-in."
        ),
        distinguishes_from=("antigravity-ide.brain",),
        search_by_default=False,
        discovery=(
            DiscoverySpec(
                store="antigravity-ide.brain_resolved",
                adapter_id="antigravity_ide.brain_resolved_text.v1",
                path_kind="store_file",
                source_kind="text",
                home_subpath=("brain",),
                glob="**/task.md.resolved*",
            ),
        ),
    ),
    StoreDescriptor(
        agent="antigravity-ide",
        store_id="antigravity-ide.skills",
        role=StoreRole.INSTRUCTION,
        format=StoreFormat.MARKDOWN_FRONTMATTER,
        path_pattern="${HOME}/.gemini/antigravity/skills/**/*.md",
        observed_version=_ANTIGRAVITY_IDE_OBSERVED_VERSION,
        observed_at=_ANTIGRAVITY_IDE_OBSERVED_AT,
        schema_notes="Markdown skill definitions and instructions, not conversation history.",
        search_by_default=False,
        search_notes="Inspectable only; not searched by default.",
        discovery=(
            DiscoverySpec(
                store="antigravity-ide.skills",
                adapter_id="antigravity_ide.skills_text.v1",
                data_version="antigravity_ide.skills_text.v1",
                path_kind="store_file",
                source_kind="text",
                home_subpath=("skills",),
                glob="**/*.md",
            ),
        ),
    ),
    StoreDescriptor(
        agent="antigravity-ide",
        store_id="antigravity-ide.user_settings",
        role=StoreRole.APP_STATE,
        format=StoreFormat.PROTOBUF,
        path_pattern="${HOME}/.gemini/antigravity/user_settings.pb",
        observed_version=_ANTIGRAVITY_IDE_OBSERVED_VERSION,
        observed_at=_ANTIGRAVITY_IDE_OBSERVED_AT,
        schema_notes="Protobuf user settings. Configuration, not chat content.",
        search_by_default=False,
    ),
    StoreDescriptor(
        agent="antigravity-ide",
        store_id="antigravity-ide.mcp_config",
        role=StoreRole.APP_STATE,
        format=StoreFormat.JSON_OBJECT,
        path_pattern="${HOME}/.gemini/antigravity/mcp_config.json",
        observed_version=_ANTIGRAVITY_IDE_OBSERVED_VERSION,
        observed_at=_ANTIGRAVITY_IDE_OBSERVED_AT,
        schema_notes="MCP server configuration. Configuration, not chat content.",
        search_by_default=False,
    ),
    StoreDescriptor(
        agent="antigravity-ide",
        store_id="antigravity-ide.server",
        role=StoreRole.SOURCE_TREE,
        format=StoreFormat.OPAQUE,
        path_pattern="${HOME}/.antigravity-server/",
        observed_version=_ANTIGRAVITY_IDE_OBSERVED_VERSION,
        observed_at=_ANTIGRAVITY_IDE_OBSERVED_AT,
        schema_notes="Local IDE server state and binaries. Not conversation history.",
        search_by_default=False,
    ),
    StoreDescriptor(
        agent="antigravity-ide",
        store_id="antigravity-ide.cache",
        role=StoreRole.CACHE,
        format=StoreFormat.OPAQUE,
        path_pattern="${HOME}/.cache/antigravity/staging/",
        observed_version=_ANTIGRAVITY_IDE_OBSERVED_VERSION,
        observed_at=_ANTIGRAVITY_IDE_OBSERVED_AT,
        schema_notes="Staging cache files. Cache state, not conversation history.",
        search_by_default=False,
    ),
)
