"""codex store descriptors for the agentgrep catalogue."""

from __future__ import annotations

from agentgrep.store_catalog._common import _CODEX_OBSERVED_AT
from agentgrep.stores import (
    DiscoverySpec,
    StoreCoverage,
    StoreDescriptor,
    StoreFormat,
    StoreRole,
    VersionDetectionStrategy,
)

_CODEX_OBSERVED_VERSION = "codex-cli 0.154.0"
"""App version the Codex rows below were verified against.

The observation date lives in ``observed_at`` alone. Repeating it here
is how one row drifted to a date its own module constant disagreed with.
``observations/`` records the store shapes seen at this version.
"""


_CODEX_STORES: tuple[StoreDescriptor, ...] = (
    StoreDescriptor(
        agent="codex",
        store_id="codex.history",
        role=StoreRole.PROMPT_HISTORY,
        format=StoreFormat.JSONL,
        path_pattern="${CODEX_HOME or ${HOME}/.codex}/history.jsonl",
        env_overrides=("CODEX_HOME",),
        observed_version=_CODEX_OBSERVED_VERSION,
        observed_at=_CODEX_OBSERVED_AT,
        upstream_ref=("github.com/openai/codex@3fb81667/codex-rs/message-history/src/lib.rs#L56"),
        schema_notes=(
            "`HistoryEntry { session_id: String, ts: u64 (unix seconds), text: "
            "String }` — one record per user prompt, append-only across all threads. "
            "The legacy `history.json` array uses `{command, timestamp}`, where "
            "`timestamp` is a number in milliseconds rather than a string. Neither "
            "shape records a cwd, branch, or model: this is a flat prompt log, so "
            "records carry no origin and no model by design — `codex.sessions` is "
            "the store that has them."
        ),
        sample_record='{"session_id":"...","ts":1747509826,"text":"<redacted>"}',
        distinguishes_from=("codex.sessions",),
        search_by_default=True,
        version_strategies=(
            VersionDetectionStrategy.VERSION_CHECK,
            VersionDetectionStrategy.SHAPE_INFERENCE,
            VersionDetectionStrategy.CATALOG_OBSERVATION,
        ),
        discovery=(
            DiscoverySpec(
                store="codex.history",
                adapter_id="codex.history_json.v1",
                data_version="codex.history_json.legacy",
                path_kind="history_file",
                source_kind="json",
                files=("history.json",),
            ),
            DiscoverySpec(
                store="codex.history",
                adapter_id="codex.history_jsonl.v1",
                data_version="codex.history_jsonl.current",
                path_kind="history_file",
                source_kind="jsonl",
                files=("history.jsonl",),
            ),
        ),
    ),
    StoreDescriptor(
        agent="codex",
        store_id="codex.sessions",
        role=StoreRole.PRIMARY_CHAT,
        format=StoreFormat.JSONL,
        path_pattern=(
            "${CODEX_HOME or ${HOME}/.codex}/sessions/YYYY/MM/DD/"
            "rollout-YYYY-MM-DDThh-mm-ss-<uuid>.jsonl"
        ),
        env_overrides=("CODEX_HOME",),
        observed_version=_CODEX_OBSERVED_VERSION,
        observed_at=_CODEX_OBSERVED_AT,
        upstream_ref=("github.com/openai/codex@3fb81667/codex-rs/protocol/src/protocol.rs#L2929"),
        schema_notes=(
            "JSONL `RolloutItem` tagged enum (`type` + `payload`). agentgrep reads "
            "`session_meta`, `turn_context`, and `response_item` and skips the other "
            "variants, among them `compacted`, `event_msg`, "
            "`inter_agent_communication_metadata`, and `token_usage_record`. "
            "First line is a `SessionMetaLine` with `id`, `timestamp`, "
            "`cwd`, `cli_version`, optional `git` info — but no model slug: it "
            "carries `model_provider` (`openai`), while the slug lives on the "
            "per-turn `turn_context` payload (`model`). Older root-level "
            "`sessions/rollout-*.json` files are JSON objects with `session` "
            "metadata and an `items` array of message-like records."
        ),
        sample_record='{"type":"response_item","payload":{"role":"user","content":"<redacted>"}}',
        distinguishes_from=("codex.history",),
        search_by_default=True,
        search_notes=(
            "Full per-thread transcript with tool calls; `codex.history` is the "
            "user-prompts-only audit log."
        ),
        version_strategies=(
            VersionDetectionStrategy.EMBEDDED_METADATA,
            VersionDetectionStrategy.SHAPE_INFERENCE,
            VersionDetectionStrategy.CATALOG_OBSERVATION,
        ),
        discovery=(
            DiscoverySpec(
                store="codex.sessions",
                adapter_id="codex.sessions_jsonl.v1",
                data_version="codex.sessions.rollout.v1",
                path_kind="session_file",
                source_kind="jsonl",
                home_subpath=("sessions",),
                glob="*.jsonl",
            ),
            DiscoverySpec(
                store="codex.sessions",
                adapter_id="codex.sessions_legacy_json.v1",
                data_version="codex.sessions.legacy_json.v1",
                path_kind="session_file",
                source_kind="json",
                home_subpath=("sessions",),
                glob="rollout-*.json",
            ),
        ),
    ),
    StoreDescriptor(
        agent="codex",
        store_id="codex.session_index",
        role=StoreRole.APP_STATE,
        format=StoreFormat.JSONL,
        path_pattern="${CODEX_HOME or ${HOME}/.codex}/session_index.jsonl",
        env_overrides=("CODEX_HOME",),
        observed_version=_CODEX_OBSERVED_VERSION,
        observed_at=_CODEX_OBSERVED_AT,
        upstream_ref="github.com/openai/codex@3fb81667/codex-rs/rollout/src/session_index.rs",
        schema_notes=(
            "Append-only JSONL session index with `id`, `thread_name`, and "
            "`updated_at`. It summarizes sessions but does not replace the full "
            "`sessions/**/*.jsonl` transcripts."
        ),
        coverage=StoreCoverage.INSPECTABLE,
        search_by_default=False,
        version_strategies=(
            VersionDetectionStrategy.SHAPE_INFERENCE,
            VersionDetectionStrategy.CATALOG_OBSERVATION,
        ),
        discovery=(
            DiscoverySpec(
                store="codex.session_index",
                adapter_id="codex.session_index_jsonl.v1",
                data_version="codex.session_index.jsonl.v1",
                path_kind="store_file",
                source_kind="jsonl",
                files=("session_index.jsonl",),
            ),
        ),
    ),
    StoreDescriptor(
        agent="codex",
        store_id="codex.state_db",
        role=StoreRole.APP_STATE,
        format=StoreFormat.SQLITE,
        path_pattern="${CODEX_SQLITE_HOME or ${CODEX_HOME or ${HOME}/.codex}}/state_5.sqlite",
        env_overrides=("CODEX_HOME", "CODEX_SQLITE_HOME"),
        observed_version=_CODEX_OBSERVED_VERSION,
        observed_at=_CODEX_OBSERVED_AT,
        upstream_ref="github.com/openai/codex@3fb81667/codex-rs/state/src/lib.rs#L95",
        schema_notes=(
            "Codex state DB; schema managed via migrations. Observed prompt-bearing "
            "columns include `threads.first_user_message`, `threads.preview`, "
            "`threads.title`, and `agent_jobs.instruction`."
        ),
        coverage=StoreCoverage.INSPECTABLE,
        search_by_default=False,
        version_strategies=(
            VersionDetectionStrategy.SHAPE_INFERENCE,
            VersionDetectionStrategy.CATALOG_OBSERVATION,
        ),
        discovery=(
            DiscoverySpec(
                store="codex.state_db",
                adapter_id="codex.state_sqlite.v1",
                data_version="codex.state.sqlite.v5",
                path_kind="sqlite_db",
                source_kind="sqlite",
                root_key="codex_sqlite",
                files=("state_5.sqlite",),
            ),
        ),
    ),
    StoreDescriptor(
        agent="codex",
        store_id="codex.logs_db",
        role=StoreRole.APP_STATE,
        format=StoreFormat.SQLITE,
        path_pattern="${CODEX_SQLITE_HOME or ${CODEX_HOME or ${HOME}/.codex}}/logs_2.sqlite",
        env_overrides=("CODEX_HOME", "CODEX_SQLITE_HOME"),
        observed_version=_CODEX_OBSERVED_VERSION,
        observed_at=_CODEX_OBSERVED_AT,
        upstream_ref="github.com/openai/codex@3fb81667/codex-rs/state/src/lib.rs#L92",
        schema_notes=(
            "Codex logs DB (`LOGS_DB_FILENAME` in `codex-rs/state/src/lib.rs`). "
            "The `_N.sqlite` files at the Codex root (`logs_2.sqlite`, "
            "`state_5.sqlite`) belong to the Codex CLI, not Cursor."
        ),
        coverage=StoreCoverage.CATALOG_ONLY,
        search_by_default=False,
        version_strategies=(
            VersionDetectionStrategy.SHAPE_INFERENCE,
            VersionDetectionStrategy.CATALOG_OBSERVATION,
        ),
        discovery=(
            DiscoverySpec(
                store="codex.logs_db",
                adapter_id="codex.logs_sqlite.v1",
                data_version="codex.logs.sqlite.v2",
                path_kind="sqlite_db",
                source_kind="sqlite",
                root_key="codex_sqlite",
                files=("logs_2.sqlite",),
            ),
        ),
    ),
    StoreDescriptor(
        agent="codex",
        store_id="codex.memories_db",
        role=StoreRole.PERSISTENT_MEMORY,
        format=StoreFormat.SQLITE,
        path_pattern="${CODEX_SQLITE_HOME or ${CODEX_HOME or ${HOME}/.codex}}/memories_1.sqlite",
        env_overrides=("CODEX_HOME", "CODEX_SQLITE_HOME"),
        observed_version=_CODEX_OBSERVED_VERSION,
        observed_at=_CODEX_OBSERVED_AT,
        schema_notes=(
            "SQLite memory pipeline state. Observed tables include `stage1_outputs` "
            "with raw memory, rollout summary, slug, usage, and selection columns."
        ),
        coverage=StoreCoverage.INSPECTABLE,
        search_by_default=False,
        version_strategies=(
            VersionDetectionStrategy.SHAPE_INFERENCE,
            VersionDetectionStrategy.CATALOG_OBSERVATION,
        ),
        discovery=(
            DiscoverySpec(
                store="codex.memories_db",
                adapter_id="codex.memories_sqlite.v1",
                data_version="codex.memories.sqlite.v1",
                path_kind="sqlite_db",
                source_kind="sqlite",
                root_key="codex_sqlite",
                files=("memories_1.sqlite",),
            ),
        ),
    ),
    StoreDescriptor(
        agent="codex",
        store_id="codex.thread_history_db",
        role=StoreRole.PRIMARY_CHAT,
        format=StoreFormat.SQLITE,
        path_pattern=(
            "${CODEX_SQLITE_HOME or ${CODEX_HOME or ${HOME}/.codex}}/thread_history_1.sqlite"
        ),
        env_overrides=("CODEX_HOME", "CODEX_SQLITE_HOME"),
        observed_version=_CODEX_OBSERVED_VERSION,
        observed_at=_CODEX_OBSERVED_AT,
        schema_notes=(
            "SQLite projection of the rollout transcript. `thread_items(thread_id, "
            "turn_id, item_id, rollout_ordinal, created_at_ms, item_json, item_type, "
            "updated_at_ordinal)` carries the turn payload, with a partial index "
            "`idx_thread_items_user_messages` on `item_type = 'userMessage'`. "
            "`thread_turns` adds `first_user_item_id`, `final_agent_item_id`, and "
            "`rollout_byte_offset`. Documented, not searched: the same turns are "
            "already read from `codex.sessions`, so parsing both would double every "
            "hit. The byte offset makes this the index a targeted route would use."
        ),
        distinguishes_from=("codex.sessions",),
        coverage=StoreCoverage.CATALOG_ONLY,
        search_by_default=False,
        version_strategies=(
            VersionDetectionStrategy.SHAPE_INFERENCE,
            VersionDetectionStrategy.CATALOG_OBSERVATION,
        ),
    ),
    StoreDescriptor(
        agent="codex",
        store_id="codex.queue_db",
        role=StoreRole.APP_STATE,
        format=StoreFormat.SQLITE,
        path_pattern="${CODEX_SQLITE_HOME or ${CODEX_HOME or ${HOME}/.codex}}/queue_1.sqlite",
        env_overrides=("CODEX_HOME", "CODEX_SQLITE_HOME"),
        observed_version=_CODEX_OBSERVED_VERSION,
        observed_at=_CODEX_OBSERVED_AT,
        schema_notes=(
            "Pending user turns not yet sent. `queued_items(id, thread_id, "
            "payload_json, queue_order, created_at_ms, updated_at_ms)` with a unique "
            "index on `(thread_id, queue_order)`. `payload_json` holds prompt text, "
            "so the store is prompt-bearing, but a queued turn is one the user has "
            "not committed to; it is documented rather than searched."
        ),
        coverage=StoreCoverage.CATALOG_ONLY,
        search_by_default=False,
        version_strategies=(
            VersionDetectionStrategy.SHAPE_INFERENCE,
            VersionDetectionStrategy.CATALOG_OBSERVATION,
        ),
    ),
    StoreDescriptor(
        agent="codex",
        store_id="codex.attachments",
        role=StoreRole.SUPPLEMENTARY_CHAT,
        format=StoreFormat.TEXT,
        path_pattern=(
            "${CODEX_HOME or ${HOME}/.codex}/attachments/<attachment_uuid>/pasted-text-<n>.txt"
        ),
        env_overrides=("CODEX_HOME",),
        observed_version=_CODEX_OBSERVED_VERSION,
        observed_at=_CODEX_OBSERVED_AT,
        schema_notes=(
            "Plain-text spillover for pastes too large to inline in a turn, one "
            "directory per attachment id. The directory name is an attachment id, "
            "not a thread id, so an attachment does not name the session that used "
            "it. Parity with `cursor-cli.uploads`."
        ),
        coverage=StoreCoverage.INSPECTABLE,
        search_by_default=False,
        version_strategies=(VersionDetectionStrategy.CATALOG_OBSERVATION,),
    ),
    StoreDescriptor(
        agent="codex",
        store_id="codex.editor_drafts",
        role=StoreRole.APP_STATE,
        format=StoreFormat.TEXT,
        path_pattern="${CODEX_HOME or ${HOME}/.codex}/editor/.tmp<random>.md",
        env_overrides=("CODEX_HOME",),
        observed_version=_CODEX_OBSERVED_VERSION,
        observed_at=_CODEX_OBSERVED_AT,
        upstream_ref=("github.com/openai/codex@6c59264b/codex-rs/tui/src/external_editor.rs#L119"),
        schema_notes=(
            "The Markdown file the TUI hands to your external editor, seeded with "
            "the composer's text. Codex deletes it once the editor exits, so a file "
            "that remains holds a draft from an edit that never returned."
        ),
        distinguishes_from=("codex.history",),
        coverage=StoreCoverage.CATALOG_ONLY,
        search_by_default=False,
        version_strategies=(VersionDetectionStrategy.CATALOG_OBSERVATION,),
    ),
    StoreDescriptor(
        agent="codex",
        store_id="codex.goals_db",
        role=StoreRole.PLAN,
        format=StoreFormat.SQLITE,
        path_pattern="${CODEX_SQLITE_HOME or ${CODEX_HOME or ${HOME}/.codex}}/goals_1.sqlite",
        env_overrides=("CODEX_HOME", "CODEX_SQLITE_HOME"),
        observed_version=_CODEX_OBSERVED_VERSION,
        observed_at=_CODEX_OBSERVED_AT,
        schema_notes=(
            "SQLite goal tracker with `thread_goals(objective, status, "
            "token_budget, tokens_used, time_used_seconds, created_at_ms, "
            "updated_at_ms)`."
        ),
        coverage=StoreCoverage.INSPECTABLE,
        search_by_default=False,
        version_strategies=(
            VersionDetectionStrategy.SHAPE_INFERENCE,
            VersionDetectionStrategy.CATALOG_OBSERVATION,
        ),
        discovery=(
            DiscoverySpec(
                store="codex.goals_db",
                adapter_id="codex.goals_sqlite.v1",
                data_version="codex.goals.sqlite.v1",
                path_kind="sqlite_db",
                source_kind="sqlite",
                root_key="codex_sqlite",
                files=("goals_1.sqlite",),
            ),
        ),
    ),
    StoreDescriptor(
        agent="codex",
        store_id="codex.external_agent_imports",
        role=StoreRole.APP_STATE,
        format=StoreFormat.JSON_OBJECT,
        path_pattern="${CODEX_HOME or ${HOME}/.codex}/external_agent_session_imports.json",
        env_overrides=("CODEX_HOME",),
        observed_version=_CODEX_OBSERVED_VERSION,
        observed_at=_CODEX_OBSERVED_AT,
        upstream_ref="github.com/openai/codex@3fb81667/codex-rs/external-agent-sessions/src/ledger.rs",
        schema_notes=(
            "Import ledger with `records` carrying source path, content hash, "
            "imported thread id, and import timestamp."
        ),
        coverage=StoreCoverage.CATALOG_ONLY,
        search_by_default=False,
        version_strategies=(
            VersionDetectionStrategy.SHAPE_INFERENCE,
            VersionDetectionStrategy.CATALOG_OBSERVATION,
        ),
        discovery=(
            DiscoverySpec(
                store="codex.external_agent_imports",
                adapter_id="codex.external_imports_json.v1",
                data_version="codex.external_imports.json.v1",
                path_kind="store_file",
                source_kind="json",
                files=("external_agent_session_imports.json",),
            ),
        ),
    ),
    StoreDescriptor(
        agent="codex",
        store_id="codex.instructions",
        role=StoreRole.INSTRUCTION,
        format=StoreFormat.TEXT,
        path_pattern="${CODEX_HOME or ${HOME}/.codex}/instructions.md",
        env_overrides=("CODEX_HOME",),
        observed_version=_CODEX_OBSERVED_VERSION,
        observed_at=_CODEX_OBSERVED_AT,
        schema_notes="User-level Codex instructions loaded into new sessions.",
        coverage=StoreCoverage.INSPECTABLE,
        search_by_default=False,
        discovery=(
            DiscoverySpec(
                store="codex.instructions",
                adapter_id="codex.instructions_text.v1",
                path_kind="store_file",
                source_kind="text",
                files=("instructions.md",),
            ),
        ),
    ),
    StoreDescriptor(
        agent="codex",
        store_id="codex.memories",
        role=StoreRole.PERSISTENT_MEMORY,
        format=StoreFormat.MARKDOWN_FRONTMATTER,
        path_pattern="${CODEX_HOME or ${HOME}/.codex}/memories/",
        env_overrides=("CODEX_HOME",),
        observed_version=_CODEX_OBSERVED_VERSION,
        observed_at=_CODEX_OBSERVED_AT,
        schema_notes=(
            "Persistent memory workspace: `MEMORY.md`, `memory_summary.md`, "
            "`raw_memories.md`, rollout summaries, and skill memory folders."
        ),
        coverage=StoreCoverage.INSPECTABLE,
        search_by_default=False,
        version_strategies=(
            VersionDetectionStrategy.SHAPE_INFERENCE,
            VersionDetectionStrategy.CATALOG_OBSERVATION,
        ),
        discovery=(
            DiscoverySpec(
                store="codex.memories",
                adapter_id="codex.memories_text.v1",
                data_version="codex.memories.markdown.v1",
                path_kind="store_file",
                source_kind="text",
                home_subpath=("memories",),
                glob="*.md",
                path_parts_excluded=(".git",),
            ),
        ),
    ),
    StoreDescriptor(
        agent="codex",
        store_id="codex.config",
        role=StoreRole.APP_STATE,
        format=StoreFormat.TEXT,
        path_pattern="${CODEX_HOME or ${HOME}/.codex}/{config.toml,*.toml}",
        env_overrides=("CODEX_HOME",),
        observed_version=_CODEX_OBSERVED_VERSION,
        observed_at=_CODEX_OBSERVED_AT,
        schema_notes=(
            "Codex TOML configuration, including optional `sqlite_home`. "
            "It can affect discovery roots but is not prompt history."
        ),
        coverage=StoreCoverage.CATALOG_ONLY,
        search_by_default=False,
        discovery=(
            DiscoverySpec(
                store="codex.config",
                adapter_id="codex.config_toml.v1",
                data_version="codex.config.toml.v1",
                path_kind="store_file",
                source_kind="text",
                files=("config.toml",),
            ),
            DiscoverySpec(
                store="codex.config",
                adapter_id="codex.config_toml.v1",
                data_version="codex.managed_config.toml.v1",
                path_kind="store_file",
                source_kind="text",
                files=("managed_config.toml",),
            ),
            DiscoverySpec(
                store="codex.config",
                adapter_id="codex.config_toml.v1",
                data_version="codex.environments.toml.v1",
                path_kind="store_file",
                source_kind="text",
                files=("environments.toml",),
            ),
        ),
    ),
    StoreDescriptor(
        agent="codex",
        store_id="codex.config_backups",
        role=StoreRole.APP_STATE,
        format=StoreFormat.TEXT,
        path_pattern="${CODEX_HOME or ${HOME}/.codex}/{config.toml.bak*,config.toml.backup-*}",
        env_overrides=("CODEX_HOME",),
        observed_version=_CODEX_OBSERVED_VERSION,
        observed_at=_CODEX_OBSERVED_AT,
        schema_notes="Historical config backups. Catalogued separately from active config.",
        coverage=StoreCoverage.CATALOG_ONLY,
        search_by_default=False,
        discovery=(
            DiscoverySpec(
                store="codex.config_backups",
                adapter_id="codex.config_backup_toml.v1",
                data_version="codex.config_backup.toml.v1",
                path_kind="store_file",
                source_kind="text",
                glob="config.toml.bak*",
            ),
            DiscoverySpec(
                store="codex.config_backups",
                adapter_id="codex.config_backup_toml.v1",
                data_version="codex.config_backup.toml.v1",
                path_kind="store_file",
                source_kind="text",
                glob="config.toml.backup-*",
            ),
        ),
    ),
    StoreDescriptor(
        agent="codex",
        store_id="codex.auth",
        role=StoreRole.APP_STATE,
        format=StoreFormat.JSON_OBJECT,
        path_pattern="${CODEX_HOME or ${HOME}/.codex}/auth.json",
        env_overrides=("CODEX_HOME",),
        observed_version=_CODEX_OBSERVED_VERSION,
        observed_at=_CODEX_OBSERVED_AT,
        schema_notes="Authentication state. Documented but never enumerated or searched.",
        coverage=StoreCoverage.PRIVATE,
        search_by_default=False,
    ),
    StoreDescriptor(
        agent="codex",
        store_id="codex.installation_id",
        role=StoreRole.APP_STATE,
        format=StoreFormat.TEXT,
        path_pattern="${CODEX_HOME or ${HOME}/.codex}/installation_id",
        env_overrides=("CODEX_HOME",),
        observed_version=_CODEX_OBSERVED_VERSION,
        observed_at=_CODEX_OBSERVED_AT,
        schema_notes="Stable local installation identifier. Documented but never enumerated.",
        coverage=StoreCoverage.PRIVATE,
        search_by_default=False,
    ),
    StoreDescriptor(
        agent="codex",
        store_id="codex.secrets",
        role=StoreRole.APP_STATE,
        format=StoreFormat.OPAQUE,
        path_pattern="${CODEX_HOME or ${HOME}/.codex}/secrets/",
        env_overrides=("CODEX_HOME",),
        observed_version=_CODEX_OBSERVED_VERSION,
        observed_at=_CODEX_OBSERVED_AT,
        schema_notes="Local secret store. Documented but never enumerated or searched.",
        coverage=StoreCoverage.PRIVATE,
        search_by_default=False,
    ),
    StoreDescriptor(
        agent="codex",
        store_id="codex.env",
        role=StoreRole.APP_STATE,
        format=StoreFormat.TEXT,
        path_pattern="${CODEX_HOME or ${HOME}/.codex}/.env",
        env_overrides=("CODEX_HOME",),
        observed_version=_CODEX_OBSERVED_VERSION,
        observed_at=_CODEX_OBSERVED_AT,
        schema_notes="Environment file for local runtime configuration. Private inventory only.",
        coverage=StoreCoverage.PRIVATE,
        search_by_default=False,
    ),
    StoreDescriptor(
        agent="codex",
        store_id="codex.update_check",
        role=StoreRole.APP_STATE,
        format=StoreFormat.JSON_OBJECT,
        path_pattern="${CODEX_HOME or ${HOME}/.codex}/update-check.json",
        env_overrides=("CODEX_HOME",),
        observed_version=_CODEX_OBSERVED_VERSION,
        observed_at=_CODEX_OBSERVED_AT,
        schema_notes="Update-check cache metadata; not prompt history.",
        coverage=StoreCoverage.CATALOG_ONLY,
        search_by_default=False,
        discovery=(
            DiscoverySpec(
                store="codex.update_check",
                adapter_id="codex.app_state_json_summary.v1",
                data_version="codex.update_check.json.v1",
                path_kind="store_file",
                source_kind="json",
                files=("update-check.json",),
            ),
        ),
    ),
    StoreDescriptor(
        agent="codex",
        store_id="codex.version_file",
        role=StoreRole.APP_STATE,
        format=StoreFormat.JSON_OBJECT,
        path_pattern="${CODEX_HOME or ${HOME}/.codex}/version.json",
        env_overrides=("CODEX_HOME",),
        observed_version=_CODEX_OBSERVED_VERSION,
        observed_at=_CODEX_OBSERVED_AT,
        schema_notes="Local app-version cache used as an inventory hint.",
        coverage=StoreCoverage.CATALOG_ONLY,
        search_by_default=False,
        discovery=(
            DiscoverySpec(
                store="codex.version_file",
                adapter_id="codex.app_state_json_summary.v1",
                data_version="codex.version_file.json.v1",
                path_kind="store_file",
                source_kind="json",
                files=("version.json",),
            ),
        ),
    ),
    StoreDescriptor(
        agent="codex",
        store_id="codex.personality_migration",
        role=StoreRole.APP_STATE,
        format=StoreFormat.TEXT,
        path_pattern="${CODEX_HOME or ${HOME}/.codex}/.personality_migration",
        env_overrides=("CODEX_HOME",),
        observed_version=_CODEX_OBSERVED_VERSION,
        observed_at=_CODEX_OBSERVED_AT,
        schema_notes="Migration marker for Codex personality defaults; not prompt history.",
        coverage=StoreCoverage.CATALOG_ONLY,
        search_by_default=False,
        discovery=(
            DiscoverySpec(
                store="codex.personality_migration",
                adapter_id="codex.file_metadata_summary.v1",
                data_version="codex.personality_migration.marker.v1",
                path_kind="store_file",
                source_kind="text",
                files=(".personality_migration",),
            ),
        ),
    ),
    StoreDescriptor(
        agent="codex",
        store_id="codex.model_cache",
        role=StoreRole.CACHE,
        format=StoreFormat.JSON_OBJECT,
        path_pattern="${CODEX_HOME or ${HOME}/.codex}/models_cache.json",
        env_overrides=("CODEX_HOME",),
        observed_version=_CODEX_OBSERVED_VERSION,
        observed_at=_CODEX_OBSERVED_AT,
        schema_notes="Cached model metadata: client version, ETag, fetch time, and models.",
        coverage=StoreCoverage.CATALOG_ONLY,
        search_by_default=False,
        discovery=(
            DiscoverySpec(
                store="codex.model_cache",
                adapter_id="codex.app_state_json_summary.v1",
                data_version="codex.model_cache.json.v1",
                path_kind="store_file",
                source_kind="json",
                files=("models_cache.json",),
            ),
        ),
    ),
    StoreDescriptor(
        agent="codex",
        store_id="codex.internal_storage",
        role=StoreRole.APP_STATE,
        format=StoreFormat.JSON_OBJECT,
        path_pattern="${CODEX_HOME or ${HOME}/.codex}/internal_storage.json",
        env_overrides=("CODEX_HOME",),
        observed_version=_CODEX_OBSERVED_VERSION,
        observed_at=_CODEX_OBSERVED_AT,
        schema_notes="Small app flags and migration markers.",
        coverage=StoreCoverage.CATALOG_ONLY,
        search_by_default=False,
        discovery=(
            DiscoverySpec(
                store="codex.internal_storage",
                adapter_id="codex.app_state_json_summary.v1",
                data_version="codex.internal_storage.json.v1",
                path_kind="store_file",
                source_kind="json",
                files=("internal_storage.json",),
            ),
        ),
    ),
    StoreDescriptor(
        agent="codex",
        store_id="codex.plugins",
        role=StoreRole.INSTRUCTION,
        format=StoreFormat.OPAQUE,
        path_pattern="${CODEX_HOME or ${HOME}/.codex}/plugins/",
        env_overrides=("CODEX_HOME",),
        observed_version=_CODEX_OBSERVED_VERSION,
        observed_at=_CODEX_OBSERVED_AT,
        schema_notes="Installed plugin bundles, commands, skills, and cached metadata.",
        coverage=StoreCoverage.INSPECTABLE,
        search_by_default=False,
        version_strategies=(
            VersionDetectionStrategy.SHAPE_INFERENCE,
            VersionDetectionStrategy.CATALOG_OBSERVATION,
        ),
        discovery=(
            DiscoverySpec(
                store="codex.plugins",
                adapter_id="codex.plugin_manifest_json.v1",
                data_version="codex.plugin_manifest.json.v1",
                path_kind="store_file",
                source_kind="json",
                home_subpath=("plugins",),
                glob="plugin.json",
                path_parts_excluded=(".git",),
            ),
            DiscoverySpec(
                store="codex.plugins",
                adapter_id="codex.plugin_instruction_text.v1",
                data_version="codex.plugin_instruction.markdown.v1",
                path_kind="store_file",
                source_kind="text",
                home_subpath=("plugins",),
                glob="*.md",
                path_parts_required=("commands",),
                path_parts_excluded=(".git",),
            ),
            DiscoverySpec(
                store="codex.plugins",
                adapter_id="codex.plugin_instruction_text.v1",
                data_version="codex.plugin_instruction.markdown.v1",
                path_kind="store_file",
                source_kind="text",
                home_subpath=("plugins",),
                glob="*.md",
                path_parts_required=("agents",),
                path_parts_excluded=(".git",),
            ),
            DiscoverySpec(
                store="codex.plugins",
                adapter_id="codex.plugin_instruction_text.v1",
                data_version="codex.plugin_instruction.markdown.v1",
                path_kind="store_file",
                source_kind="text",
                home_subpath=("plugins",),
                glob="*.md",
                path_parts_required=("skills",),
                path_parts_excluded=(".git",),
            ),
            DiscoverySpec(
                store="codex.plugins",
                adapter_id="codex.plugin_instruction_text.v1",
                data_version="codex.plugin_instruction.markdown.v1",
                path_kind="store_file",
                source_kind="text",
                home_subpath=("plugins",),
                glob="*.md",
                path_parts_required=("custom-skills",),
                path_parts_excluded=(".git",),
            ),
            DiscoverySpec(
                store="codex.plugins",
                adapter_id="codex.plugin_hooks_json.v1",
                data_version="codex.plugin_hooks.json.v1",
                path_kind="store_file",
                source_kind="json",
                home_subpath=("plugins",),
                glob="hooks.json",
                path_parts_required=("hooks",),
                path_parts_excluded=(".git",),
            ),
        ),
    ),
    StoreDescriptor(
        agent="codex",
        store_id="codex.plugin_marketplace",
        role=StoreRole.APP_STATE,
        format=StoreFormat.JSON_OBJECT,
        path_pattern="${CODEX_HOME or ${HOME}/.codex}/plugins/**/marketplace.json",
        env_overrides=("CODEX_HOME",),
        observed_version=_CODEX_OBSERVED_VERSION,
        observed_at=_CODEX_OBSERVED_AT,
        schema_notes=(
            "Plugin marketplace metadata for installed or project-local plugin roots. "
            "Summarized structurally, not searched as prompt history."
        ),
        coverage=StoreCoverage.INSPECTABLE,
        search_by_default=False,
        version_strategies=(
            VersionDetectionStrategy.SHAPE_INFERENCE,
            VersionDetectionStrategy.CATALOG_OBSERVATION,
        ),
        discovery=(
            DiscoverySpec(
                store="codex.plugin_marketplace",
                adapter_id="codex.plugin_marketplace_json.v1",
                data_version="codex.plugin_marketplace.json.v1",
                path_kind="store_file",
                source_kind="json",
                home_subpath=("plugins",),
                glob="marketplace.json",
                path_parts_excluded=(".git",),
            ),
        ),
    ),
    StoreDescriptor(
        agent="codex",
        store_id="codex.skills",
        role=StoreRole.INSTRUCTION,
        format=StoreFormat.TEXT,
        path_pattern="${CODEX_HOME or ${HOME}/.codex}/skills/",
        env_overrides=("CODEX_HOME",),
        observed_version=_CODEX_OBSERVED_VERSION,
        observed_at=_CODEX_OBSERVED_AT,
        schema_notes="User-level Codex skill instructions.",
        coverage=StoreCoverage.INSPECTABLE,
        search_by_default=False,
        version_strategies=(
            VersionDetectionStrategy.SHAPE_INFERENCE,
            VersionDetectionStrategy.CATALOG_OBSERVATION,
        ),
        discovery=(
            DiscoverySpec(
                store="codex.skills",
                adapter_id="codex.skills_text.v1",
                data_version="codex.skills.markdown.v1",
                path_kind="store_file",
                source_kind="text",
                home_subpath=("skills",),
                glob="*.md",
                path_parts_excluded=(".git",),
            ),
        ),
    ),
    StoreDescriptor(
        agent="codex",
        store_id="codex.rules",
        role=StoreRole.INSTRUCTION,
        format=StoreFormat.TEXT,
        path_pattern="${CODEX_HOME or ${HOME}/.codex}/rules/",
        env_overrides=("CODEX_HOME",),
        observed_version=_CODEX_OBSERVED_VERSION,
        observed_at=_CODEX_OBSERVED_AT,
        schema_notes="User-defined rule files that can affect agent behavior.",
        coverage=StoreCoverage.INSPECTABLE,
        search_by_default=False,
        version_strategies=(
            VersionDetectionStrategy.SHAPE_INFERENCE,
            VersionDetectionStrategy.CATALOG_OBSERVATION,
        ),
        discovery=(
            DiscoverySpec(
                store="codex.rules",
                adapter_id="codex.rules_text.v1",
                data_version="codex.rules.text.v1",
                path_kind="store_file",
                source_kind="text",
                home_subpath=("rules",),
                glob="*.rules",
                path_parts_excluded=(".git",),
            ),
            DiscoverySpec(
                store="codex.rules",
                adapter_id="codex.rules_text.v1",
                data_version="codex.rules.markdown.v1",
                path_kind="store_file",
                source_kind="text",
                home_subpath=("rules",),
                glob="*.md",
                path_parts_excluded=(".git",),
            ),
        ),
    ),
    StoreDescriptor(
        agent="codex",
        store_id="codex.hooks",
        role=StoreRole.APP_STATE,
        format=StoreFormat.JSON_OBJECT,
        path_pattern=(
            "${CODEX_HOME or ${HOME}/.codex}/hooks.json and "
            "${HOME}/<known_project_root>/.codex/hooks.json"
        ),
        env_overrides=("CODEX_HOME",),
        observed_version=_CODEX_OBSERVED_VERSION,
        observed_at=_CODEX_OBSERVED_AT,
        schema_notes=(
            "Hook configuration JSON. User/project hook shape is summarized without "
            "raw command values."
        ),
        coverage=StoreCoverage.CATALOG_ONLY,
        search_by_default=False,
        version_strategies=(
            VersionDetectionStrategy.SHAPE_INFERENCE,
            VersionDetectionStrategy.CATALOG_OBSERVATION,
        ),
        discovery=(
            DiscoverySpec(
                store="codex.hooks",
                adapter_id="codex.hooks_json.v1",
                data_version="codex.hooks.json.v1",
                path_kind="store_file",
                source_kind="json",
                files=("hooks.json",),
            ),
            DiscoverySpec(
                store="codex.hooks",
                adapter_id="codex.hooks_json.v1",
                data_version="codex.project_hooks.json.v1",
                path_kind="store_file",
                source_kind="json",
                root_key="codex_project",
                home_subpath=(".codex",),
                files=("hooks.json",),
            ),
        ),
    ),
    StoreDescriptor(
        agent="codex",
        store_id="codex.project_config",
        role=StoreRole.APP_STATE,
        format=StoreFormat.TEXT,
        path_pattern="${HOME}/<known_project_root>/.codex/config.toml",
        env_overrides=("CODEX_HOME",),
        observed_version=_CODEX_OBSERVED_VERSION,
        observed_at=_CODEX_OBSERVED_AT,
        schema_notes=(
            "Project-local Codex configuration discovered only from roots already "
            "referenced by local Codex sessions."
        ),
        coverage=StoreCoverage.CATALOG_ONLY,
        search_by_default=False,
        version_strategies=(
            VersionDetectionStrategy.SHAPE_INFERENCE,
            VersionDetectionStrategy.CATALOG_OBSERVATION,
        ),
        discovery=(
            DiscoverySpec(
                store="codex.project_config",
                adapter_id="codex.project_config_toml.v1",
                data_version="codex.project_config.toml.v1",
                path_kind="store_file",
                source_kind="text",
                root_key="codex_project",
                home_subpath=(".codex",),
                files=("config.toml",),
            ),
        ),
    ),
    StoreDescriptor(
        agent="codex",
        store_id="codex.project_skills",
        role=StoreRole.INSTRUCTION,
        format=StoreFormat.TEXT,
        path_pattern="${HOME}/<known_project_root>/.codex/skills/",
        env_overrides=("CODEX_HOME",),
        observed_version=_CODEX_OBSERVED_VERSION,
        observed_at=_CODEX_OBSERVED_AT,
        schema_notes=(
            "Project-local Codex skill Markdown from known project roots. Kept "
            "non-default because project instructions are broader than chat history."
        ),
        coverage=StoreCoverage.INSPECTABLE,
        search_by_default=False,
        version_strategies=(
            VersionDetectionStrategy.SHAPE_INFERENCE,
            VersionDetectionStrategy.CATALOG_OBSERVATION,
        ),
        discovery=(
            DiscoverySpec(
                store="codex.project_skills",
                adapter_id="codex.project_skill_text.v1",
                data_version="codex.project_skills.markdown.v1",
                path_kind="store_file",
                source_kind="text",
                root_key="codex_project",
                home_subpath=(".codex", "skills"),
                glob="*.md",
                path_parts_excluded=(".git",),
            ),
        ),
    ),
    StoreDescriptor(
        agent="codex",
        store_id="codex.policy",
        role=StoreRole.APP_STATE,
        format=StoreFormat.OPAQUE,
        path_pattern="${CODEX_HOME or ${HOME}/.codex}/policy/",
        env_overrides=("CODEX_HOME",),
        observed_version=_CODEX_OBSERVED_VERSION,
        observed_at=_CODEX_OBSERVED_AT,
        schema_notes="Policy state and downloaded policy metadata.",
        coverage=StoreCoverage.PRIVATE,
        search_by_default=False,
    ),
    StoreDescriptor(
        agent="codex",
        store_id="codex.runtime_cache",
        role=StoreRole.CACHE,
        format=StoreFormat.OPAQUE,
        path_pattern="${CODEX_HOME or ${HOME}/.codex}/{cache,tmp,.tmp,sqlite}/",
        env_overrides=("CODEX_HOME",),
        observed_version=_CODEX_OBSERVED_VERSION,
        observed_at=_CODEX_OBSERVED_AT,
        schema_notes=(
            "Runtime cache and temporary files. The `sqlite/` subdir is a "
            "nested/alternate SQLite home (a candidate `CODEX_SQLITE_HOME` / "
            "config `sqlite_home` target) holding full same-schema DB copies, "
            "not `-wal`/`-shm` sidecars — those belong to codex.sqlite_sidecars."
        ),
        coverage=StoreCoverage.CATALOG_ONLY,
        search_by_default=False,
    ),
    StoreDescriptor(
        agent="codex",
        store_id="codex.arg0_runtime",
        role=StoreRole.APP_STATE,
        format=StoreFormat.JSON_OBJECT,
        path_pattern="${CODEX_HOME or ${HOME}/.codex}/tmp/arg0/",
        env_overrides=("CODEX_HOME",),
        observed_version=_CODEX_OBSERVED_VERSION,
        observed_at=_CODEX_OBSERVED_AT,
        schema_notes="Arg0 runtime coordination state, summarized without raw values.",
        coverage=StoreCoverage.CATALOG_ONLY,
        search_by_default=False,
        discovery=(
            DiscoverySpec(
                store="codex.arg0_runtime",
                adapter_id="codex.app_state_json_summary.v1",
                data_version="codex.arg0_runtime.json.v1",
                path_kind="store_file",
                source_kind="json",
                home_subpath=("tmp", "arg0"),
                glob="*.json",
            ),
        ),
    ),
    StoreDescriptor(
        agent="codex",
        store_id="codex.sqlite_sidecars",
        role=StoreRole.CACHE,
        format=StoreFormat.OPAQUE,
        path_pattern="${CODEX_SQLITE_HOME or ${CODEX_HOME or ${HOME}/.codex}}/*.sqlite-{wal,shm}",
        env_overrides=("CODEX_HOME", "CODEX_SQLITE_HOME"),
        observed_version=_CODEX_OBSERVED_VERSION,
        observed_at=_CODEX_OBSERVED_AT,
        schema_notes="SQLite WAL/SHM sidecars for Codex databases.",
        coverage=StoreCoverage.CATALOG_ONLY,
        search_by_default=False,
    ),
    StoreDescriptor(
        agent="codex",
        store_id="codex.log_files",
        role=StoreRole.APP_STATE,
        format=StoreFormat.TEXT,
        path_pattern="${CODEX_HOME or ${HOME}/.codex}/log/",
        env_overrides=("CODEX_HOME",),
        observed_version=_CODEX_OBSERVED_VERSION,
        observed_at=_CODEX_OBSERVED_AT,
        schema_notes=(
            "Runtime log files. Search the structured logs DB only by explicit inspection."
        ),
        coverage=StoreCoverage.CATALOG_ONLY,
        search_by_default=False,
        discovery=(
            DiscoverySpec(
                store="codex.log_files",
                adapter_id="codex.file_metadata_summary.v1",
                data_version="codex.log_file.text.v1",
                path_kind="store_file",
                source_kind="text",
                home_subpath=("log",),
                glob="*",
            ),
        ),
    ),
    StoreDescriptor(
        agent="codex",
        store_id="codex.process_manager",
        role=StoreRole.APP_STATE,
        format=StoreFormat.JSON_OBJECT,
        path_pattern="${CODEX_HOME or ${HOME}/.codex}/process_manager/",
        env_overrides=("CODEX_HOME",),
        observed_version=_CODEX_OBSERVED_VERSION,
        observed_at=_CODEX_OBSERVED_AT,
        schema_notes="Process-manager state for background jobs.",
        coverage=StoreCoverage.CATALOG_ONLY,
        search_by_default=False,
        discovery=(
            DiscoverySpec(
                store="codex.process_manager",
                adapter_id="codex.app_state_json_summary.v1",
                data_version="codex.process_manager.json.v1",
                path_kind="store_file",
                source_kind="json",
                home_subpath=("process_manager",),
                glob="*.json",
            ),
        ),
    ),
    StoreDescriptor(
        agent="codex",
        store_id="codex.shell_snapshots",
        role=StoreRole.APP_STATE,
        format=StoreFormat.OPAQUE,
        path_pattern="${CODEX_HOME or ${HOME}/.codex}/shell_snapshots/",
        env_overrides=("CODEX_HOME",),
        observed_version=_CODEX_OBSERVED_VERSION,
        observed_at=_CODEX_OBSERVED_AT,
        schema_notes="Shell/runtime snapshots, not prompt history.",
        coverage=StoreCoverage.CATALOG_ONLY,
        search_by_default=False,
        discovery=(
            DiscoverySpec(
                store="codex.shell_snapshots",
                adapter_id="codex.file_metadata_summary.v1",
                data_version="codex.shell_snapshot.text.v1",
                path_kind="store_file",
                source_kind="text",
                home_subpath=("shell_snapshots",),
                glob="*.sh",
            ),
        ),
    ),
    StoreDescriptor(
        agent="codex",
        store_id="codex.tui_thread_capabilities",
        role=StoreRole.APP_STATE,
        format=StoreFormat.OPAQUE,
        path_pattern=(
            "${CODEX_HOME or ${HOME}/.codex}/tui-thread-reference-capabilities/<thread_id>"
        ),
        env_overrides=("CODEX_HOME",),
        observed_version=_CODEX_OBSERVED_VERSION,
        observed_at=_CODEX_OBSERVED_AT,
        schema_notes=(
            "Empty marker files, one per thread and named by its id. The name is the only content."
        ),
        coverage=StoreCoverage.CATALOG_ONLY,
        search_by_default=False,
    ),
)
