"""grok store descriptors for the agentgrep catalogue."""

from __future__ import annotations

from agentgrep.store_catalog._common import _GROK_OBSERVED_AT
from agentgrep.stores import (
    DiscoverySpec,
    StoreCoverage,
    StoreDescriptor,
    StoreFormat,
    StoreRole,
)

_GROK_OBSERVED_VERSION = "grok 1.0.25"
"""App version the Grok CLI rows below were verified against.

The observation date lives in ``observed_at`` alone. Repeating it here
is how one row drifted to a date its own module constant disagreed with.
``observations/`` records the store shapes seen at this version.
"""


_GROK_STORES: tuple[StoreDescriptor, ...] = (
    StoreDescriptor(
        agent="grok",
        store_id="grok.prompt_history",
        role=StoreRole.PROMPT_HISTORY,
        format=StoreFormat.JSONL,
        path_pattern=(
            "${GROK_HOME or ${HOME}/.grok}/sessions/<url_encoded_project>/prompt_history.jsonl"
        ),
        env_overrides=("GROK_HOME",),
        observed_version=_GROK_OBSERVED_VERSION,
        observed_at=_GROK_OBSERVED_AT,
        schema_notes=(
            "JSONL per-project user-prompt audit log. Keys: `timestamp` "
            "(ISO-8601 nanosecond), `session_id` (UUIDv7), `prompt` (text), "
            "`is_bash` (bool)."
        ),
        sample_record=(
            '{"timestamp":"2026-05-25T10:00:00.000000000Z",'
            '"session_id":"...","prompt":"<redacted>","is_bash":false}'
        ),
        search_by_default=True,
        discovery=(
            DiscoverySpec(
                store="grok.prompt_history",
                adapter_id="grok.prompt_history_jsonl.v1",
                path_kind="history_file",
                source_kind="jsonl",
                home_subpath=("sessions",),
                glob="prompt_history.jsonl",
            ),
        ),
    ),
    StoreDescriptor(
        agent="grok",
        store_id="grok.sessions",
        role=StoreRole.PRIMARY_CHAT,
        format=StoreFormat.JSONL,
        path_pattern=(
            "${GROK_HOME or ${HOME}/.grok}/sessions/"
            "<url_encoded_project>/<session_uuid>/chat_history.jsonl"
        ),
        env_overrides=("GROK_HOME",),
        observed_version=_GROK_OBSERVED_VERSION,
        observed_at=_GROK_OBSERVED_AT,
        schema_notes=(
            "JSONL full session transcripts. `type` discriminates "
            "system/user/assistant/reasoning/tool_result/backend_tool_call. "
            "Assistant tool calls live in a `tool_calls` array on the "
            "assistant record; `backend_tool_call` records host-side calls. "
            "`reasoning` records carry a readable `summary` array of "
            "`{type: summary_text, text}` blocks plus an opaque "
            "`encrypted_content` blob; agentgrep does not surface them because "
            "the adapter reads only `content`, which reasoning records omit. "
            "`content` is text or a content-blocks array. No record of any "
            "type carries a `timestamp` key, so the adapter backfills the "
            "source mtime. Agent-injected turns are written as `user` records "
            "tagged with `synthetic_reason` (`system_reminder`, "
            "`project_instructions`); the adapter does not yet read that key, "
            "so they are indexed as user prompts."
        ),
        sample_record=(
            '{"type":"user","content":"<redacted>","synthetic_reason":"system_reminder"}'
        ),
        distinguishes_from=("grok.prompt_history",),
        search_by_default=True,
        search_notes=(
            "Full per-session transcript with tool calls; "
            "`grok.prompt_history` is the user-prompts-only audit log."
        ),
        discovery=(
            DiscoverySpec(
                store="grok.sessions",
                adapter_id="grok.sessions_jsonl.v1",
                path_kind="session_file",
                source_kind="jsonl",
                home_subpath=("sessions",),
                glob="chat_history.jsonl",
            ),
        ),
    ),
    StoreDescriptor(
        agent="grok",
        store_id="grok.session_search",
        role=StoreRole.SUPPLEMENTARY_CHAT,
        format=StoreFormat.SQLITE,
        path_pattern="${GROK_HOME or ${HOME}/.grok}/sessions/session_search.sqlite",
        env_overrides=("GROK_HOME",),
        observed_version=_GROK_OBSERVED_VERSION,
        observed_at=_GROK_OBSERVED_AT,
        schema_notes=(
            "SQLite with FTS5. Table `session_docs`: session_id, cwd, "
            "updated_at (unix seconds), title (generated), content "
            "(full-text index), content_hash, last_indexed_offset. A `meta` "
            "table carries session_search_schema_version (4) and "
            "last_bootstrap_at; `PRAGMA user_version` stays 0."
        ),
        search_by_default=True,
        search_notes=(
            "Pre-indexed session titles and content for fast lookup. "
            "De-duplicate against `grok.sessions` by session_id."
        ),
        discovery=(
            DiscoverySpec(
                store="grok.session_search",
                adapter_id="grok.session_search_sqlite.v1",
                path_kind="sqlite_db",
                source_kind="sqlite",
                home_subpath=("sessions",),
                files=("session_search.sqlite",),
            ),
        ),
    ),
    StoreDescriptor(
        agent="grok",
        store_id="grok.subagents",
        role=StoreRole.SUPPLEMENTARY_CHAT,
        format=StoreFormat.JSON_OBJECT,
        path_pattern=(
            "${GROK_HOME or ${HOME}/.grok}/sessions/<url_encoded_project>/"
            "<session_uuid>/subagents/<subagent_uuid>/meta.json"
        ),
        env_overrides=("GROK_HOME",),
        observed_version=_GROK_OBSERVED_VERSION,
        observed_at=_GROK_OBSERVED_AT,
        schema_notes=(
            "Per-subagent dispatch record. One JSON object per delegated "
            "subagent: `prompt` (the delegated instruction), `description`, "
            "`subagent_type`, `tool_calls`, `turns`, and parent/child session "
            "linkage. `effective_model_id` and `child_cwd` name the model and "
            "working directory the child ran under. The child session keeps its "
            "own `chat_history.jsonl`, read as `grok.sessions`; this record is "
            "the delegation itself. `tool_calls` is a count, not a list."
        ),
        sample_record=(
            '{"subagent_id":"...","parent_session_id":"...",'
            '"subagent_type":"...","description":"<redacted>",'
            '"prompt":"<redacted>","tool_calls":0}'
        ),
        distinguishes_from=("grok.sessions",),
        search_by_default=True,
        search_notes=(
            "Subagent dispatch prompts are conversation content; the child's own "
            "turns are in its session transcript. Parity with "
            "claude.projects.subagent and cursor-cli.subagent_transcripts."
        ),
        discovery=(
            DiscoverySpec(
                store="grok.subagents",
                adapter_id="grok.subagents_json.v1",
                path_kind="session_file",
                source_kind="json",
                home_subpath=("sessions",),
                glob="meta.json",
                path_parts_required=("subagents",),
            ),
        ),
    ),
    StoreDescriptor(
        agent="grok",
        store_id="grok.sessions.events",
        role=StoreRole.APP_STATE,
        format=StoreFormat.JSONL,
        path_pattern=(
            "${GROK_HOME or ${HOME}/.grok}/sessions/"
            "<url_encoded_project>/<session_uuid>/events.jsonl"
        ),
        env_overrides=("GROK_HOME",),
        observed_version=_GROK_OBSERVED_VERSION,
        observed_at=_GROK_OBSERVED_AT,
        schema_notes=(
            "Per-session event stream. `type` values include turn_started, "
            "turn_ended, loop_started, first_token, phase_changed, "
            "tool_started, tool_completed, permission_requested/resolved, and "
            "an mcp_* lifecycle family (illustrative, not exhaustive). A "
            'per-record `schema_version` ("1.0") rides on turn_started.'
        ),
    ),
    StoreDescriptor(
        agent="grok",
        store_id="grok.sessions.summary",
        role=StoreRole.APP_STATE,
        format=StoreFormat.JSON_OBJECT,
        path_pattern=(
            "${GROK_HOME or ${HOME}/.grok}/sessions/"
            "<url_encoded_project>/<session_uuid>/summary.json"
        ),
        env_overrides=("GROK_HOME",),
        observed_version=_GROK_OBSERVED_VERSION,
        observed_at=_GROK_OBSERVED_AT,
        schema_notes=(
            "Per-session summary: id, cwd, session_summary, created_at, "
            "updated_at, num_messages, current_model_id, git metadata, "
            "generated_title, agent_name."
        ),
    ),
    StoreDescriptor(
        agent="grok",
        store_id="grok.memory",
        role=StoreRole.PERSISTENT_MEMORY,
        format=StoreFormat.MARKDOWN_FRONTMATTER,
        path_pattern="${GROK_HOME or ${HOME}/.grok}/memory/**/MEMORY.md",
        env_overrides=("GROK_HOME",),
        observed_version=_GROK_OBSERVED_VERSION,
        observed_at=_GROK_OBSERVED_AT,
        schema_notes=(
            "Persistent memory Markdown managed by Grok's memory system. Covers "
            "the flat `memory/MEMORY.md` and the per-project "
            "`memory/<project-slug>-<hash8>/MEMORY.md` subtree. The companion "
            "`index.sqlite` is not separately enumerated; it is a chunk store "
            "(`chunks`) with both an FTS5 mirror (`chunks_fts`) and a "
            "sqlite-vec embedding index (`chunks_vec`), not an FTS index "
            "alone. Grok derives the directory name from the git remote URL, "
            "so every clone and worktree of one repository shares a memory "
            "directory. Inspectable opt-in."
        ),
        coverage=StoreCoverage.INSPECTABLE,
        search_by_default=False,
        discovery=(
            DiscoverySpec(
                store="grok.memory",
                adapter_id="grok.memory_text.v1",
                path_kind="store_file",
                source_kind="text",
                home_subpath=("memory",),
                glob="**/MEMORY.md",
            ),
        ),
    ),
    StoreDescriptor(
        agent="grok",
        store_id="grok.logs",
        role=StoreRole.APP_STATE,
        format=StoreFormat.JSONL,
        path_pattern="${GROK_HOME or ${HOME}/.grok}/logs/unified.jsonl",
        env_overrides=("GROK_HOME",),
        observed_version=_GROK_OBSERVED_VERSION,
        observed_at=_GROK_OBSERVED_AT,
        schema_notes=(
            "Structured application logs: ts, src, pid, lvl, msg, ctx. "
            "Debugging diagnostics, not chat content."
        ),
        search_by_default=False,
    ),
    StoreDescriptor(
        agent="grok",
        store_id="grok.worktrees_db",
        role=StoreRole.APP_STATE,
        format=StoreFormat.SQLITE,
        path_pattern="${GROK_HOME or ${HOME}/.grok}/worktrees.db",
        env_overrides=("GROK_HOME",),
        observed_version=_GROK_OBSERVED_VERSION,
        observed_at=_GROK_OBSERVED_AT,
        schema_notes="SQLite database tracking git worktrees created by Grok.",
        search_by_default=False,
    ),
    StoreDescriptor(
        agent="grok",
        store_id="grok.config",
        role=StoreRole.APP_STATE,
        format=StoreFormat.OPAQUE,
        path_pattern="${GROK_HOME or ${HOME}/.grok}/config.toml",
        env_overrides=("GROK_HOME",),
        observed_version=_GROK_OBSERVED_VERSION,
        observed_at=_GROK_OBSERVED_AT,
        schema_notes="TOML configuration file.",
        search_by_default=False,
    ),
    StoreDescriptor(
        agent="grok",
        store_id="grok.plans",
        role=StoreRole.PLAN,
        format=StoreFormat.MARKDOWN_FRONTMATTER,
        path_pattern=(
            "${GROK_HOME or ${HOME}/.grok}/sessions/<url_encoded_project>/<session_uuid>/plan.md"
        ),
        env_overrides=("GROK_HOME",),
        observed_version=_GROK_OBSERVED_VERSION,
        observed_at=_GROK_OBSERVED_AT,
        schema_notes=(
            "Per-session plan-mode Markdown — the agent's working plan for the "
            "session. Inspectable, parity with claude.plans and "
            "cursor-cli.plans; not searched by default."
        ),
        coverage=StoreCoverage.INSPECTABLE,
        search_by_default=False,
        discovery=(
            DiscoverySpec(
                store="grok.plans",
                adapter_id="grok.plans_text.v1",
                path_kind="store_file",
                source_kind="text",
                home_subpath=("sessions",),
                glob="plan.md",
            ),
        ),
    ),
    StoreDescriptor(
        agent="grok",
        store_id="grok.sessions.system_prompt",
        role=StoreRole.APP_STATE,
        format=StoreFormat.TEXT,
        path_pattern=(
            "${GROK_HOME or ${HOME}/.grok}/sessions/<url_encoded_project>/"
            "<session_uuid>/system_prompt.txt"
        ),
        env_overrides=("GROK_HOME",),
        observed_version=_GROK_OBSERVED_VERSION,
        observed_at=_GROK_OBSERVED_AT,
        schema_notes=(
            "The rendered system prompt for the session (agent instructions "
            "plus injected context). Agent-side boilerplate, largely shared "
            "across sessions; documented for inventory, not searched."
        ),
        search_by_default=False,
    ),
    StoreDescriptor(
        agent="grok",
        store_id="grok.sessions.prompt_context",
        role=StoreRole.APP_STATE,
        format=StoreFormat.JSON_OBJECT,
        path_pattern=(
            "${GROK_HOME or ${HOME}/.grok}/sessions/<url_encoded_project>/"
            "<session_uuid>/prompt_context.json"
        ),
        env_overrides=("GROK_HOME",),
        observed_version=_GROK_OBSERVED_VERSION,
        observed_at=_GROK_OBSERVED_AT,
        schema_notes=(
            "Session prompt-context metadata: working_directory, "
            "agents_md_files, persona_summaries, os_name, current_date, "
            "prompt_mode, audience, version. Configuration, not chat."
        ),
        search_by_default=False,
    ),
    StoreDescriptor(
        agent="grok",
        store_id="grok.sessions.hunk_records",
        role=StoreRole.APP_STATE,
        format=StoreFormat.JSONL,
        path_pattern=(
            "${GROK_HOME or ${HOME}/.grok}/sessions/<url_encoded_project>/"
            "<session_uuid>/hunk_records.jsonl"
        ),
        env_overrides=("GROK_HOME",),
        observed_version=_GROK_OBSERVED_VERSION,
        observed_at=_GROK_OBSERVED_AT,
        schema_notes=(
            "Edit-attribution JSONL (filePath, hunkStart/End, linesAdded/"
            "Removed, authorType, promptIndex, eventType). Code-change "
            "telemetry, no prompt payload; documented, not searched."
        ),
        search_by_default=False,
    ),
    StoreDescriptor(
        agent="grok",
        store_id="grok.sessions.updates",
        role=StoreRole.APP_STATE,
        format=StoreFormat.JSONL,
        path_pattern=(
            "${GROK_HOME or ${HOME}/.grok}/sessions/<url_encoded_project>/"
            "<session_uuid>/updates.jsonl"
        ),
        env_overrides=("GROK_HOME",),
        observed_version=_GROK_OBSERVED_VERSION,
        observed_at=_GROK_OBSERVED_AT,
        schema_notes=(
            "ACP-style session/update notification stream (method, "
            "params.sessionId, update payloads). Protocol traffic, not chat; "
            "documented, not searched."
        ),
        search_by_default=False,
    ),
    StoreDescriptor(
        agent="grok",
        store_id="grok.sessions.terminal",
        role=StoreRole.APP_STATE,
        format=StoreFormat.TEXT,
        path_pattern=(
            "${GROK_HOME or ${HOME}/.grok}/sessions/<url_encoded_project>/"
            "<session_uuid>/terminal/call-<id>.log"
        ),
        env_overrides=("GROK_HOME",),
        observed_version=_GROK_OBSERVED_VERSION,
        observed_at=_GROK_OBSERVED_AT,
        schema_notes=(
            "Per-tool-call terminal stdout/stderr logs (thousands per active "
            "project). Tool output, not chat, and high-volume; documented for "
            "inventory and deliberately not searched."
        ),
        search_by_default=False,
    ),
    StoreDescriptor(
        agent="grok",
        store_id="grok.skills",
        role=StoreRole.INSTRUCTION,
        format=StoreFormat.MARKDOWN_FRONTMATTER,
        path_pattern="${GROK_HOME or ${HOME}/.grok}/skills/<name>/SKILL.md",
        env_overrides=("GROK_HOME",),
        observed_version=_GROK_OBSERVED_VERSION,
        observed_at=_GROK_OBSERVED_AT,
        schema_notes=(
            "`skills/<name>/SKILL.md` skill-instruction files a user authors. "
            "The directory is present but empty at grok 1.0.25: the bundled "
            "set lives under `bundled/skills/` and is no longer mirrored here. "
            "Parity with claude.skills and cursor-cli.skills."
        ),
        coverage=StoreCoverage.CATALOG_ONLY,
        search_by_default=False,
    ),
    StoreDescriptor(
        agent="grok",
        store_id="grok.grove",
        role=StoreRole.APP_STATE,
        format=StoreFormat.JSON_OBJECT,
        path_pattern="${GROK_HOME or ${HOME}/.grok}/grove/pin_gc_orphans.json",
        env_overrides=("GROK_HOME",),
        observed_version=_GROK_OBSERVED_VERSION,
        observed_at=_GROK_OBSERVED_AT,
        schema_notes=("Pin garbage-collection state: an `orphans` list. Not conversation content."),
        coverage=StoreCoverage.CATALOG_ONLY,
        search_by_default=False,
    ),
    StoreDescriptor(
        agent="grok",
        store_id="grok.campaigns_state",
        role=StoreRole.APP_STATE,
        format=StoreFormat.JSON_OBJECT,
        path_pattern="${GROK_HOME or ${HOME}/.grok}/campaigns_state.json",
        env_overrides=("GROK_HOME",),
        observed_version=_GROK_OBSERVED_VERSION,
        observed_at=_GROK_OBSERVED_AT,
        schema_notes=("Holds `dismissed_ids`. Not conversation content."),
        coverage=StoreCoverage.CATALOG_ONLY,
        search_by_default=False,
    ),
)
