"""jcode (jcode swarm CLI) store descriptors for the agentgrep catalogue."""

from __future__ import annotations

from agentgrep.store_catalog._common import _JCODE_OBSERVED_AT
from agentgrep.stores import (
    DiscoverySpec,
    StoreCoverage,
    StoreDescriptor,
    StoreFormat,
    StoreRole,
)

_JCODE_OBSERVED_VERSION = "jcode v0.58.5 (devbox live tree, 2026-09-24)"
"""Captured from a live filesystem walk on this devbox, not a scripted
``observations/`` fixture. Version string read off a session's own
``env_snapshots[0].jcode_version``.
"""


_JCODE_STORES: tuple[StoreDescriptor, ...] = (
    StoreDescriptor(
        agent="jcode",
        store_id="jcode.prompt_history",
        role=StoreRole.PROMPT_HISTORY,
        format=StoreFormat.JSONL,
        path_pattern="${JCODE_HOME or ${HOME}/.jcode}/prompt-history.jsonl",
        env_overrides=("JCODE_HOME",),
        observed_version=_JCODE_OBSERVED_VERSION,
        observed_at=_JCODE_OBSERVED_AT,
        schema_notes=(
            "JSONL per-prompt audit log, append-only across all sessions. "
            "Each line is a bare JSON string -- the prompt text -- not an "
            "object; there is no per-line timestamp, session id, or cwd."
        ),
        sample_record='"<redacted>"',
        distinguishes_from=("jcode.sessions",),
        search_by_default=True,
        discovery=(
            DiscoverySpec(
                store="jcode.prompt_history",
                adapter_id="jcode.prompt_history_jsonl.v1",
                path_kind="history_file",
                source_kind="jsonl",
                files=("prompt-history.jsonl",),
            ),
        ),
    ),
    StoreDescriptor(
        agent="jcode",
        store_id="jcode.sessions",
        role=StoreRole.PRIMARY_CHAT,
        format=StoreFormat.JSON_OBJECT,
        path_pattern="${JCODE_HOME or ${HOME}/.jcode}/sessions/session_<word>_<epoch_ms>_<hash16>.json",
        env_overrides=("JCODE_HOME",),
        observed_version=_JCODE_OBSERVED_VERSION,
        observed_at=_JCODE_OBSERVED_AT,
        schema_notes=(
            "One JSON object per session (flat file, not a directory tree). "
            "Top-level `id`, `title` (nullable), `working_dir` (cwd), `model`, "
            "`provider_key`, `status`, and a `messages` array of "
            "`{id, role, content: [{type: text, text}], display_role, "
            "timestamp}`. `.bak` siblings hold the same shape from a prior "
            "checkpoint (e.g. before a crash) and are read by the same "
            "adapter; a crashed/superseded session can carry unique content "
            "only its `.bak` still has."
        ),
        sample_record=(
            '{"id":"session_cactus_...","working_dir":"/home/mhugo/code/jcode",'
            '"messages":[{"role":"user","content":[{"type":"text","text":"<redacted>"}]}]}'
        ),
        distinguishes_from=("jcode.prompt_history",),
        search_by_default=True,
        search_notes="Full per-session transcript with tool-call metadata folded into content.",
        discovery=(
            DiscoverySpec(
                store="jcode.sessions",
                adapter_id="jcode.sessions_json.v1",
                path_kind="session_file",
                source_kind="json",
                home_subpath=("sessions",),
                glob="session_*.json",
            ),
            DiscoverySpec(
                store="jcode.sessions",
                adapter_id="jcode.sessions_json.v1",
                data_version="jcode.sessions.backup.v1",
                path_kind="session_file",
                source_kind="json",
                home_subpath=("sessions",),
                glob="session_*.bak",
            ),
        ),
    ),
    StoreDescriptor(
        agent="jcode",
        store_id="jcode.goals",
        role=StoreRole.PLAN,
        format=StoreFormat.OPAQUE,
        path_pattern="${JCODE_HOME or ${HOME}/.jcode}/goals/",
        env_overrides=("JCODE_HOME",),
        observed_version=_JCODE_OBSERVED_VERSION,
        observed_at=_JCODE_OBSERVED_AT,
        schema_notes="Durable-goal working directory; not walked by this catalogue yet.",
        coverage=StoreCoverage.CATALOG_ONLY,
        search_by_default=False,
    ),
)
