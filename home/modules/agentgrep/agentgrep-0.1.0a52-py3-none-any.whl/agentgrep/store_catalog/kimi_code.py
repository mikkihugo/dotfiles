"""kimi-code (Kimi Code CLI) store descriptors for the agentgrep catalogue."""

from __future__ import annotations

from agentgrep.store_catalog._common import _KIMI_CODE_OBSERVED_AT
from agentgrep.stores import (
    DiscoverySpec,
    StoreCoverage,
    StoreDescriptor,
    StoreFormat,
    StoreRole,
)

_KIMI_CODE_OBSERVED_VERSION = "kimi-code (devbox live tree, 2026-09-24)"
"""No packaged app-version string was read off disk for this observation;
the date lives in ``observed_at`` and this row records how the shapes below
were captured -- a live filesystem walk on this devbox, not a scripted
``observations/`` fixture the way the other agents in this catalogue are.
"""


_KIMI_CODE_STORES: tuple[StoreDescriptor, ...] = (
    StoreDescriptor(
        agent="kimi-code",
        store_id="kimi-code.sessions",
        role=StoreRole.PRIMARY_CHAT,
        format=StoreFormat.JSONL,
        path_pattern=(
            "${HOME}/.kimi-code/sessions/wd_<slug>_<hash12>/session_<uuid>/agents/<agentId>/wire.jsonl"
        ),
        observed_version=_KIMI_CODE_OBSERVED_VERSION,
        observed_at=_KIMI_CODE_OBSERVED_AT,
        schema_notes=(
            "JSONL wire log for one session agent (`main` or a swarm sub-agent "
            "`agent-<n>`). Every line has a top-level `type`. The visible "
            "conversation lives in two shapes: `context.append_message` "
            "(`message.role`, `message.content` as text or a content-blocks "
            "array -- user prompts and injected `<system-reminder>` turns; no "
            "assistant `context.append_message` was ever observed) and "
            "`context.append_loop_event` rows whose `event.type` is "
            "`content.part` with `event.part.type == \"text\"` (the assistant's "
            "streamed reply). `event.part.type == \"think\"` is reasoning and is "
            "read by `kimi-code.tool_activity` instead, matching how "
            "`grok.sessions` excludes reasoning summaries from the primary "
            "transcript. The sibling `state.json` one level up carries `cwd` "
            "and `title` for the whole session; there is no per-line cwd."
        ),
        sample_record=(
            '{"type":"context.append_message","agentId":"main",'
            '"message":{"role":"user","content":[{"type":"text","text":"<redacted>"}]}}'
        ),
        distinguishes_from=("kimi-code.tool_activity",),
        search_by_default=True,
        search_notes=(
            "Primary user/assistant transcript. Tool calls, tool output, and "
            "reasoning are `kimi-code.tool_activity` (inspectable, exhaustive-only) "
            "so a default-scope search is not flooded with tool payloads."
        ),
        discovery=(
            DiscoverySpec(
                store="kimi-code.sessions",
                adapter_id="kimi_code.sessions_jsonl.v1",
                path_kind="session_file",
                source_kind="jsonl",
                home_subpath=("sessions",),
                glob="wire.jsonl",
            ),
        ),
    ),
    StoreDescriptor(
        agent="kimi-code",
        store_id="kimi-code.tool_activity",
        role=StoreRole.SUPPLEMENTARY_CHAT,
        format=StoreFormat.JSONL,
        path_pattern=(
            "${HOME}/.kimi-code/sessions/wd_<slug>_<hash12>/session_<uuid>/agents/<agentId>/wire.jsonl"
        ),
        observed_version=_KIMI_CODE_OBSERVED_VERSION,
        observed_at=_KIMI_CODE_OBSERVED_AT,
        schema_notes=(
            "The same `wire.jsonl` file as `kimi-code.sessions`, read a second "
            "time for its tool traffic and reasoning: `context.append_loop_event` "
            "rows with `event.type` in `tool.call` (name + args), `tool.result` "
            "(`event.result.output`, the text a command or MCP tool returned -- "
            "this is where a live incident string like a leaked IP or a "
            "suspicious hostname first surfaces), and `content.part` with "
            "`event.part.type == \"think\"` (the model's private reasoning). "
            "Large tool outputs get truncated inline with a pointer into "
            "`kimi-code.tool_result_files` instead of the full text."
        ),
        sample_record=(
            '{"type":"context.append_loop_event","event":{"type":"tool.result",'
            '"toolCallId":"call_...","result":{"output":"<redacted>"}}}'
        ),
        distinguishes_from=("kimi-code.sessions", "kimi-code.tool_result_files"),
        coverage=StoreCoverage.INSPECTABLE,
        search_by_default=False,
        search_notes=(
            "High-volume tool call/result/reasoning stream. Reachable via "
            "`--exhaustive` or broad-scope search, not the default fast path."
        ),
        discovery=(
            DiscoverySpec(
                store="kimi-code.tool_activity",
                adapter_id="kimi_code.tool_activity_jsonl.v1",
                path_kind="session_file",
                source_kind="jsonl",
                home_subpath=("sessions",),
                glob="wire.jsonl",
            ),
        ),
    ),
    StoreDescriptor(
        agent="kimi-code",
        store_id="kimi-code.task_output_files",
        role=StoreRole.SUPPLEMENTARY_CHAT,
        format=StoreFormat.TEXT,
        path_pattern=(
            "${HOME}/.kimi-code/sessions/wd_<slug>_<hash12>/session_<uuid>/agents/<agentId>/"
            "tasks/<tool>-<id>/output.log"
        ),
        observed_version=_KIMI_CODE_OBSERVED_VERSION,
        observed_at=_KIMI_CODE_OBSERVED_AT,
        schema_notes=(
            "Plain-text stdout/stderr log for one background or detached "
            "bash task (e.g. `Bash(run_in_background=true)`). A sibling "
            "`<tool>-<id>.json` carries `taskId`, `command`, `status`, "
            "`exitCode`, and timing, but is not itself parsed here -- the "
            "log body is the searchable payload. Files can be large "
            "(hundreds of KB), so this store is exhaustive-only."
        ),
        distinguishes_from=("kimi-code.tool_activity", "kimi-code.tool_result_files"),
        coverage=StoreCoverage.INSPECTABLE,
        search_by_default=False,
        discovery=(
            DiscoverySpec(
                store="kimi-code.task_output_files",
                adapter_id="kimi_code.task_output_text.v1",
                path_kind="store_file",
                source_kind="text",
                home_subpath=("sessions",),
                glob="**/tasks/*/output.log",
            ),
        ),
    ),
    StoreDescriptor(
        agent="kimi-code",
        store_id="kimi-code.tool_result_files",
        role=StoreRole.SUPPLEMENTARY_CHAT,
        format=StoreFormat.TEXT,
        path_pattern=(
            "${HOME}/.kimi-code/sessions/wd_<slug>_<hash12>/session_<uuid>/agents/<agentId>/"
            "tool-results/<tool>-call_<id>-<uuid>.txt"
        ),
        observed_version=_KIMI_CODE_OBSERVED_VERSION,
        observed_at=_KIMI_CODE_OBSERVED_AT,
        schema_notes=(
            "Plain-text spillover for one tool result once it exceeds Kimi "
            "Code's inline size threshold ('Tool output exceeded 50000 "
            "characters...'); `wire.jsonl` keeps only a preview plus an "
            "`output_path` pointer into this file. Files can be very large "
            "(hundreds of KB), so this store is exhaustive-only, matching "
            "`codex.attachments`."
        ),
        distinguishes_from=("kimi-code.tool_activity",),
        coverage=StoreCoverage.INSPECTABLE,
        search_by_default=False,
        discovery=(
            DiscoverySpec(
                store="kimi-code.tool_result_files",
                adapter_id="kimi_code.tool_result_text.v1",
                path_kind="store_file",
                source_kind="text",
                home_subpath=("sessions",),
                glob="**/tool-results/*.txt",
            ),
        ),
    ),
)
