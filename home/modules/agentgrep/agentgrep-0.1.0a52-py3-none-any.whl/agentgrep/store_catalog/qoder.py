"""qoder (Qoder CLI/IDE) store descriptors for the agentgrep catalogue."""

from __future__ import annotations

from agentgrep.store_catalog._common import _QODER_OBSERVED_AT
from agentgrep.stores import (
    DiscoverySpec,
    StoreCoverage,
    StoreDescriptor,
    StoreFormat,
    StoreRole,
)

_QODER_OBSERVED_VERSION = "qoder (devbox live tree, 2026-09-24; qoder-cli entrypoint 1.1.19)"
"""Captured from a live filesystem walk on this devbox, not a scripted
``observations/`` fixture. ``entrypoint: "cli"`` and ``version`` are read
directly off ``qoder.sessions`` records.
"""


_QODER_STORES: tuple[StoreDescriptor, ...] = (
    StoreDescriptor(
        agent="qoder",
        store_id="qoder.sessions",
        role=StoreRole.PRIMARY_CHAT,
        format=StoreFormat.JSONL,
        path_pattern="${HOME}/.qoder/projects/<dash_encoded_cwd>/<session_uuid>.jsonl",
        observed_version=_QODER_OBSERVED_VERSION,
        observed_at=_QODER_OBSERVED_AT,
        schema_notes=(
            "Qoder CLI's session transcript, shaped almost identically to "
            "`claude.projects`: one JSONL line per event, `type` in "
            "`workspace-directories` / `runtime-config` / `active-leaf` / "
            "`system` / `user` / `assistant`, each conversational line "
            "carrying `sessionId` and `cwd` directly (no directory-name "
            "decode needed). `message.role`/`message.content` holds the "
            "text; `content` may be a bare string or a content-blocks array. "
            "The parent directory name is the working directory with `/` "
            "replaced by `-` (e.g. `-home-mhugo` for `/home/mhugo`). The same "
            "glob also reaches two sibling shapes with the identical event "
            "envelope: `<project>/<uuid>/subagents/agent-<name>-<hash>.jsonl` "
            "(a delegated subagent's own transcript -- no `sessionId`/`cwd` "
            "on its lines, so those records get no origin and their "
            "`conversation_id` falls back to the subagent file's own stem) "
            "and `<project>/transcript/<task-id>.session.execution.jsonl` "
            "(a background/scheduled task's execution log)."
        ),
        sample_record=(
            '{"type":"user","uuid":"...","sessionId":"...","cwd":"/home/mhugo",'
            '"message":{"role":"user","content":"<redacted>"}}'
        ),
        distinguishes_from=("qoder.conversation_history",),
        search_by_default=True,
        search_notes=(
            "Qoder CLI's primary per-session transcript. A background task run "
            "through the IDE can be recorded twice: once here as "
            "`<task-id>.session.execution.jsonl` and again under "
            "`qoder.conversation_history` as `conversation-history/<task-id>/"
            "<task-id>.jsonl` -- observed for one project's `task-301` job, "
            "same prompt text, two different on-disk shapes and id schemes. "
            "agentgrep has no cross-store dedup key linking them (unlike "
            "`grok.session_search`, which shares `session_id` with "
            "`grok.sessions`), so a broad-scope search of both stores can "
            "surface that content twice."
        ),
        discovery=(
            DiscoverySpec(
                store="qoder.sessions",
                adapter_id="qoder.sessions_jsonl.v1",
                path_kind="session_file",
                source_kind="jsonl",
                home_subpath=("projects",),
                glob="*.jsonl",
            ),
        ),
    ),
    StoreDescriptor(
        agent="qoder",
        store_id="qoder.conversation_history",
        role=StoreRole.SUPPLEMENTARY_CHAT,
        format=StoreFormat.JSONL,
        path_pattern=(
            "${HOME}/.qoder/cache/projects/<repo_basename>-<hash8>/"
            "conversation-history/<conversation_id>/<conversation_id>.jsonl"
        ),
        observed_version=_QODER_OBSERVED_VERSION,
        observed_at=_QODER_OBSERVED_AT,
        schema_notes=(
            "The Qoder IDE's (qoder-server / editor extension) per-conversation "
            "chat log, distinct from the `qoder.sessions` CLI transcript. One "
            "observed project (jcode) had both: its CLI-side "
            "`projects/-home-mhugo-code-jcode/transcript/` and its IDE-side "
            "`cache/projects/jcode-22936ca3/conversation-history/` -- see the "
            "`qoder.sessions` search_notes for the resulting duplicate-content "
            "caveat. A project can also have only one of the two. "
            "Lines are `{\"role\": \"user\"|\"assistant\", \"message\": "
            "{\"content\": [{\"type\": \"text\", \"text\": ...}]}}`, with no "
            "per-line cwd or session id. `<repo_basename>-<hash8>` is a "
            "project-directory name whose 8-char suffix did not match "
            "md5/sha1/sha256[:8] of the absolute project path in a quick "
            "check, so it is treated as opaque here: records carry no `cwd` "
            "origin. `<conversation_id>` (e.g. `1d349168`, or `task-301` for a "
            "background task) is used as the session/conversation id."
        ),
        sample_record=(
            '{"role":"user","message":{"content":[{"type":"text","text":"<redacted>"}]}}'
        ),
        distinguishes_from=("qoder.sessions",),
        search_by_default=True,
        search_notes="Qoder IDE per-conversation chat log; no cwd recovered.",
        discovery=(
            DiscoverySpec(
                store="qoder.conversation_history",
                adapter_id="qoder.conversation_history_jsonl.v1",
                path_kind="session_file",
                source_kind="jsonl",
                home_subpath=("cache", "projects"),
                glob="**/conversation-history/*/*.jsonl",
            ),
        ),
    ),
    StoreDescriptor(
        agent="qoder",
        store_id="qoder.memories",
        role=StoreRole.PERSISTENT_MEMORY,
        format=StoreFormat.OPAQUE,
        path_pattern="${HOME}/.qoder/memories/",
        observed_version=_QODER_OBSERVED_VERSION,
        observed_at=_QODER_OBSERVED_AT,
        schema_notes="Persistent memory workspace directory; not walked by this catalogue yet.",
        coverage=StoreCoverage.CATALOG_ONLY,
        search_by_default=False,
    ),
)
