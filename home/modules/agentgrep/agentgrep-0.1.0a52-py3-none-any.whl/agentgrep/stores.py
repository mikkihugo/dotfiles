"""Pydantic-backed catalogue of every on-disk store agentgrep knows about.

agentgrep searches AI agent prompt and conversation stores that live in the user's
``$HOME``. Those stores move (Claude has renamed paths between minor
versions), grow (Cursor added a CLI agent with its own layout), and overlap
(Gemini keeps a pruned archive alongside its live tmp tree). Keeping that
knowledge as comments in adapter code makes it fragile: future readers can't
tell what the catalogue *was* at any given point, and there is no single
place to diff against when the next upstream rename lands.

This module defines the schema for the catalogue. ``store_catalog`` populates
it with the current entries; downstream adapters consume it.
"""

from __future__ import annotations

import datetime
import enum
import typing as t

import pydantic


class StoreFormat(enum.StrEnum):
    """On-disk encoding of a store's payload."""

    JSONL = "jsonl"
    JSON_ARRAY = "json_array"
    JSON_OBJECT = "json_object"
    SQLITE = "sqlite"
    TEXT = "text"
    MARKDOWN_FRONTMATTER = "md_frontmatter"
    PROTOBUF = "protobuf"
    OPAQUE = "opaque"


class StoreRole(enum.StrEnum):
    """Semantic role a store plays for the owning agent.

    Role narrows eligible stores by effort and scope. Fast prompt effort admits
    prompt-history roles; exhaustive and broad scopes may add chat roles.
    Coverage separately controls eligibility.
    """

    PRIMARY_CHAT = "primary_chat"
    SUPPLEMENTARY_CHAT = "supplementary_chat"
    PROMPT_HISTORY = "prompt_history"
    PERSISTENT_MEMORY = "persistent_memory"
    PLAN = "plan"
    TODO = "todo"
    INSTRUCTION = "instruction"
    APP_STATE = "app_state"
    CACHE = "cache"
    SOURCE_TREE = "source_tree"
    UNKNOWN = "unknown"


class StoreCoverage(enum.StrEnum):
    """How agentgrep treats a known store at runtime.

    ``DEFAULT_SEARCH`` stores are eligible without inventory opt-in; effort and
    scope still gate their roles. ``INSPECTABLE`` stores may join exhaustive or
    broad-scope search and explicit inventory. ``CATALOG_ONLY`` stores are never
    searched. ``PRIVATE`` stores are not enumerated.
    """

    DEFAULT_SEARCH = "default_search"
    INSPECTABLE = "inspectable"
    CATALOG_ONLY = "catalog_only"
    PRIVATE = "private"


class VersionDetectionStrategy(enum.StrEnum):
    """How agentgrep detected a concrete source's app or data version."""

    VERSION_CHECK = "version_check"
    EMBEDDED_METADATA = "embedded_metadata"
    SHAPE_INFERENCE = "shape_inference"
    CATALOG_OBSERVATION = "catalog_observation"


class VersionDetectionConfidence(enum.StrEnum):
    """Confidence level for a detected source version."""

    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


AgentName = t.Literal[
    "claude",
    "cursor-cli",
    "cursor-ide",
    "codex",
    "gemini",
    "antigravity-cli",
    "antigravity-ide",
    "grok",
    "kimi-code",
    "qoder",
    "jcode",
    "pi",
    "opencode",
    "windsurf",
    "vscode",
]
PathKind = t.Literal["history_file", "session_file", "sqlite_db", "store_file"]
SourceKind = t.Literal["json", "jsonl", "sqlite", "text", "opaque"]


class DiscoverySpec(pydantic.BaseModel):
    """Runtime metadata for discovering one store's source files.

    Catalogue rows whose store agentgrep actually scans at runtime carry a
    ``DiscoverySpec``. Rows that are documentary (planned support, opaque
    formats, source trees) leave ``StoreDescriptor.discovery`` as ``None``.

    Path resolution
    ---------------
    The discover function for an agent resolves a *base* directory
    (typically ``${HOME}/.<agent>`` or an env-override). The ``home_subpath``
    segments are appended to that base. Two enumeration modes are then
    available, used independently or together:

    - ``files`` lists specific relative filenames to check via ``is_file()``.
    - ``glob`` is a pattern walked under the resolved root via
      :func:`agentgrep.list_files_matching`. ``path_parts_required`` and
      ``path_parts_excluded`` filter glob results by path components (e.g.,
      Cursor CLI transcripts must live under ``agent-transcripts`` but the
      primary transcript store excludes nested ``subagents`` files).

    ``platform_paths`` lists absolute paths to check unconditionally, for
    stores whose canonical location depends on the operating system.
    """

    model_config = pydantic.ConfigDict(frozen=True)

    store: str
    """Runtime store key (e.g. ``"claude.projects"``)."""

    adapter_id: str
    """Runtime adapter identifier (e.g. ``"claude.projects_jsonl.v1"``)."""

    data_version: str | None = None
    """Known data-shape version for this discovery path, when stable."""

    path_kind: PathKind
    """Kind of filesystem entry the records live in."""

    source_kind: SourceKind
    """Parse format (json / jsonl / sqlite)."""

    home_subpath: tuple[str, ...] = ()
    """Path segments appended to the agent's resolved base directory."""

    platform_paths: tuple[str, ...] = ()
    """Absolute paths to check unconditionally."""

    root_key: str = "default"
    """Named discovery root to resolve this spec against."""

    files: tuple[str, ...] = ()
    """Specific relative filenames to check via ``is_file()``."""

    glob: str | None = None
    """Glob pattern walked under the resolved root."""

    path_parts_required: tuple[str, ...] = ()
    """Each named segment must appear in a glob result's ``path.parts``."""

    path_parts_excluded: tuple[str, ...] = ()
    """A glob result is skipped when any named segment appears in ``path.parts``."""


class StoreDescriptor(pydantic.BaseModel):
    """One on-disk storage location for one CLI agent.

    Each descriptor is a snapshot of how the store looked when an agentgrep
    contributor observed it. The ``observed_version`` and ``observed_at``
    fields stamp that snapshot so future readers know whether a description
    is current or stale.

    Path patterns use ``${HOME}`` and ``${<ENV>}`` tokens so the catalogue
    stays portable. Resolving a pattern against a concrete environment is the
    consumer's job — adapters typically expand the tokens themselves.
    """

    model_config = pydantic.ConfigDict(frozen=True)

    agent: AgentName
    """The CLI agent that owns this store."""

    store_id: str
    """Stable dotted identifier, e.g. ``claude.projects.session``."""

    role: StoreRole
    """Semantic role used by effort and scope discovery."""

    format: StoreFormat
    """On-disk encoding."""

    path_pattern: str
    """Path pattern with ``${HOME}``/``${<ENV>}`` and ``<placeholder>`` tokens."""

    env_overrides: tuple[str, ...] = ()
    """Environment variables that override the root, e.g. ``("CODEX_HOME",)``."""

    platform_variants: dict[str, str] = pydantic.Field(default_factory=dict)
    """Per-platform path overrides keyed by ``"linux"``/``"darwin"``/``"win32"``."""

    coverage: StoreCoverage | None = None
    """Explicit search-eligibility tier, or ``None`` to infer it."""

    version_strategies: tuple[VersionDetectionStrategy, ...] = ()
    """Strategies runtime discovery may use to identify concrete source versions."""

    observed_version: str
    """Released version (or HEAD commit) the schema notes were captured against."""

    observed_at: datetime.date
    """Date the schema notes were captured."""

    upstream_ref: str | None = None
    """Pointer to the authoritative type definition.

    Example: ``github.com/openai/codex@3fb81667/codex-rs/...#L2929``.
    """

    schema_notes: str
    """Free-text description of the record shape. Doctest-discouraged."""

    sample_record: str | None = None
    """A redacted, ~200-char sample of one record.

    Optional but recommended for primary-chat stores.
    """

    distinguishes_from: tuple[str, ...] = ()
    """Sibling ``store_id`` values this store overlaps with; explains how they differ."""

    search_by_default: bool | None = None
    """Legacy coverage hint.

    ``True`` infers ``DEFAULT_SEARCH`` when ``coverage`` is unset; otherwise
    discovery availability determines the tier.
    """

    search_notes: str | None = None
    """Free-text rationale for the search-policy decision, including de-duplication hints."""

    discovery: tuple[DiscoverySpec, ...] = ()
    """Runtime discovery specs for this store.

    Empty tuple means the row is documentary-only. Most discovered stores
    have exactly one entry; a few rows carry multiple specs because the
    same logical store has more than one on-disk shape — e.g. Codex's
    ``history.json`` and ``history.jsonl`` variants, or the modern vs.
    legacy Cursor IDE state databases.
    """

    @property
    def coverage_level(self) -> StoreCoverage:
        """Return this descriptor's effective runtime coverage level."""
        if self.coverage is not None:
            return self.coverage
        if self.search_by_default is True:
            return StoreCoverage.DEFAULT_SEARCH
        if self.discovery:
            return StoreCoverage.INSPECTABLE
        return StoreCoverage.CATALOG_ONLY


SEARCHABLE_COVERAGE: frozenset[StoreCoverage] = frozenset(
    {StoreCoverage.DEFAULT_SEARCH, StoreCoverage.INSPECTABLE},
)
"""Coverage levels a search may open.

``DEFAULT_SEARCH`` and ``INSPECTABLE`` are the only tiers search may open. Fast
prompt effort admits prompt-history roles from the default tier. Exhaustive or
broad scopes may add chat roles from either tier. Catalog-only rows remain
inventory-only.
"""


class StoreCatalog(pydantic.BaseModel):
    """Versioned registry of every store agentgrep knows about."""

    model_config = pydantic.ConfigDict(frozen=True)

    catalog_version: int = 1
    """Bump on PRs that change descriptor shape or add/remove entries."""

    captured_at: datetime.date
    """Date the catalogue snapshot was taken."""

    stores: tuple[StoreDescriptor, ...]

    def by_id(self, store_id: str) -> StoreDescriptor:
        """Return the descriptor with the given ``store_id``.

        Parameters
        ----------
        store_id : str
            The dotted identifier to look up.

        Returns
        -------
        StoreDescriptor
            The matching descriptor.

        Raises
        ------
        KeyError
            If no descriptor has that ``store_id``.
        """
        for store in self.stores:
            if store.store_id == store_id:
                return store
        raise KeyError(store_id)

    def for_agent(self, agent: AgentName) -> tuple[StoreDescriptor, ...]:
        """Return all descriptors owned by ``agent``."""
        return tuple(store for store in self.stores if store.agent == agent)


__all__ = (
    "SEARCHABLE_COVERAGE",
    "AgentName",
    "DiscoverySpec",
    "PathKind",
    "SourceKind",
    "StoreCatalog",
    "StoreCoverage",
    "StoreDescriptor",
    "StoreFormat",
    "StoreRole",
)
